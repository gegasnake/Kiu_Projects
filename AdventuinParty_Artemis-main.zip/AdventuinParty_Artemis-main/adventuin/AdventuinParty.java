package pgdp.adventuin;

import pgdp.color.RgbColor;

import java.util.*;
import java.util.stream.Collectors;

public final class AdventuinParty {
    public static Map<HatType, List<Adventuin>> groupByHatType(List<Adventuin> party){
        Map<HatType, List<Adventuin>> map = new HashMap<>();
        map.put(HatType.NO_HAT, new LinkedList<>());
        map.put(HatType.FISHY_HAT, new LinkedList<>());
        map.put(HatType.REINDEER, new LinkedList<>());
        map.put(HatType.SANTA_CLAUS, new LinkedList<>());
        for (int i = 0; i < party.size(); i++){
            map.get(party.get(i).getHatType()).add(party.get(i));
        }
        return map;
    }

    public static void printLocalizedChristmasGreetings(List<Adventuin> party){
        List<Adventuin> sorted_party = party.stream().sorted(Comparator.comparing(Adventuin::getSize)).toList();
        for (int i = 0; i < sorted_party.size(); i++){
            System.out.println(sorted_party.get(i).getLanguage().
                    getLocalizedChristmasGreeting(sorted_party.get(i).getName()));
        }
    }

    public static Map<HatType, List<Adventuin>> getAdventuinsWithLongestNamesByHatType(List<Adventuin> party){
        return party.stream()
                .collect(Collectors.groupingBy(
                        Adventuin::getHatType,
                        Collectors.collectingAndThen(
                                Collectors.maxBy(Comparator.comparingInt(x -> x.getName().length())),
                                maxAdventuin -> maxAdventuin.map(List::of).orElse(List.of())
                        )
                ));
    }


    public static Map<Integer, Double> getAverageColorBrightnessByHeight(List<Adventuin> adventuins) {
        return adventuins.stream()
                .collect(Collectors.groupingBy(
                        adv -> roundToNearestTen(adv.getSize()),
                        Collectors.averagingDouble(adv -> calculateBrightness(adv.getColor()))
                ));
    }


    private static int roundToNearestTen(int height) {
        return (height / 10) * 10;
    }

    private static double calculateBrightness(RgbColor color) {
        int red = color.getRed();
        int green = color.getGreen();
        int blue = color.getBlue();

        return (0.2126 * red + 0.7152 * green + 0.0722 * blue) / 255;
    }

    public static Map<HatType, Double> getDiffOfAvgHeightDiffsToPredecessorByHatType(List<Adventuin> party) {
        Map<HatType, Map<Integer, List<Integer>>> groupedByHatAndSize = party.stream()
                .collect(Collectors.groupingBy(
                        Adventuin::getHatType,
                        Collectors.groupingBy(Adventuin::getSize,
                                Collectors.mapping(Adventuin::getSize, Collectors.toList())
                        )
                ));

        Map<HatType, Double> result = new HashMap<>();

        groupedByHatAndSize.forEach((hatType, sizeMap) -> {
            List<Integer> negativeDifferences = new ArrayList<>();
            List<Integer> positiveDifferences = new ArrayList<>();

            sizeMap.forEach((size, heights) -> {
                for (int i = 0; i < heights.size(); i++) {
                    int predecessorIndex = (i - 1 + heights.size()) % heights.size();
                    int difference = heights.get(i) - heights.get(predecessorIndex);

                    if (difference < 0) {
                        negativeDifferences.add(difference);
                    } else if (difference > 0) {
                        positiveDifferences.add(difference);
                    }
                }
            });

            double avgNegativeDiff = negativeDifferences.isEmpty() ? 0.0 :
                    negativeDifferences.stream().mapToDouble(Integer::doubleValue).average().orElse(0.0);

            double avgPositiveDiff = positiveDifferences.isEmpty() ? 0.0 :
                    positiveDifferences.stream().mapToDouble(Integer::doubleValue).average().orElse(0.0);

            double absoluteDiff = Math.abs(avgNegativeDiff - avgPositiveDiff);
            result.put(hatType, absoluteDiff);
        });

        return result;
    }
}
