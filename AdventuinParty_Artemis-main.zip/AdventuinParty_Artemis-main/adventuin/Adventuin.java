package pgdp.adventuin;

import pgdp.color.RgbColor;

public class Adventuin {
    private String name;
    private int size;
    private RgbColor color;
    private HatType hatType;
    private Language language;

    public Adventuin(String name, int size, RgbColor color, HatType hatType, Language language) {
        this.name = name;
        this.size = size;
        this.color = color;
        this.hatType = hatType;
        this.language = language;
    }

    public String getName() {
        return name;
    }

    public int getSize() {
        return size;
    }

    public RgbColor getColor() {
        return color;
    }

    public HatType getHatType() {
        return hatType;
    }

    public Language getLanguage() {
        return language;
    }

    @Override
    public String toString() {
        return "Adventuin{name='" + name + "', size=" + size + ", color=" + color + ", hatType=" + hatType + ", language=" + language + '}';
    }

}