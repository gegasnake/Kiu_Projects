package pgdp.adventuin;

public enum HatType {
    SANTA_CLAUS, REINDEER, FISHY_HAT, NO_HAT;
}
