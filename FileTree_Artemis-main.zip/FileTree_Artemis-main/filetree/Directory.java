package filetree;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

public class Directory extends File {

	private final List<File> files;

	public Directory(Path path, List<File> files) {
		super(path);
		this.files = files;
	}

	@Override
	public Iterator<File> iterator() {
		return new TreeIterator();
	}

	private class TreeIterator implements Iterator<File> {
		private final List<Iterator<File>> iterators;
		private int currentIndex = 0;

		public TreeIterator() {
			this.iterators = new ArrayList<>();
			for (File file : files) {
				iterators.add(file.iterator());
			}
		}

		@Override
		public boolean hasNext() {
			while (currentIndex < iterators.size() && !iterators.get(currentIndex).hasNext()) {
				currentIndex++;
			}
			return currentIndex < iterators.size();
		}

		@Override
		public File next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			File nextFile = iterators.get(currentIndex).next();
			if (!iterators.get(currentIndex).hasNext()) {
				currentIndex++;
			}
			return nextFile;
		}
	}

	@Override
	public int getHeight() {
		int maxHeight = 0;
		if (files.isEmpty()){
			return 0;
		}else{
			for (File file : files) {
				if (file instanceof Directory) {
					int childHeight = ((Directory) file).getHeight();
					maxHeight = Math.max(maxHeight, childHeight);
				}
			}
		}
		return maxHeight;
	}

	@Override
	public boolean isRegularFile() {
		return false;
	}

	public List<File> getFiles() {
		return files;
	}

}
