package filetree;

import java.nio.file.Path;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class RegularFile extends File {

	public RegularFile(Path path) {
		super(path);
	}

	@Override
	public Iterator<File> iterator() {
		return new Iterator<File>() {
			private boolean hasNext = true;
			@Override
			public boolean hasNext() {
				return hasNext;
			}
			@Override
			public File next() {
				if (!hasNext()){
					throw new NoSuchElementException();
				}
				hasNext = false;
				return RegularFile.this;
			}
		};
	}

	@Override
	public int getHeight() {
		return 0;
	}

	@Override
	public boolean isRegularFile() {
		return true;
	}

}
