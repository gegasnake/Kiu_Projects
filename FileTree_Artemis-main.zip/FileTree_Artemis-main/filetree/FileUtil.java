package filetree;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class FileUtil {
	public static File toFileRepresentation(Path path) throws IOException {
		if (Files.isRegularFile(path)) {
			return new RegularFile(path);
		} else {
			List<File> files = new ArrayList<>();

			try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(path)) {
				for (Path entry : directoryStream) {
					if (Files.isRegularFile(entry)) {
						files.add(new RegularFile(entry));
					}
				}
			}

			return new Directory(path, files);
		}
	}
}
