package pgdp.company;
import pgdp.tree.Node;
import pgdp.tree.Tree;

import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;

public class Company {

    private Employee CEO;
    private Tree<Integer> employeesTree;
    private Map<Integer, Employee> employees;
    private Queue<Integer> availableIDs;
    private static int availableID = 1;
    private String name;

    public Company(String name, Employee CEO) {
        this.name = name;
        this.CEO = CEO;
        employeesTree = new Tree<>(0);
        availableIDs = new PriorityQueue<>();
        employees = new HashMap<>();
        employees.put(0, CEO);
    }

    public void addEmployee(Employee newEmployee) {
        int bossID = newEmployee.getBoss().getID();
        Node<Integer> bossNode = findNode(employeesTree.getRoot(), bossID);

        if (bossNode != null) {
            int newID;
            if (!availableIDs.isEmpty()) {
                newID = availableIDs.poll();
            } else {
                newID = availableID++;
            }

            newEmployee.setID(newID);
            employees.put(newID, newEmployee);
            bossNode.addChild(new Node<>(newID));
        }
    }

    public void fireEmployee(int ID) {
        Employee employee = employees.get(ID);
        if (employee != null && employee != CEO) {
            Node<Integer> employeeNode = findNode(employeesTree.getRoot(), ID);
            Node<Integer> bossNode = employeeNode.getParent();

            bossNode.removeChild(employeeNode);
            availableIDs.offer(ID);
            employees.remove(ID);
        }
    }

    public Employee findCommonBoss(Employee e1, Employee e2) {
        Node<Integer> commonBossNode = findLCA(employeesTree.getRoot(), e1.getID(), e2.getID());
        return employees.get(commonBossNode.getData());
    }

    public Employee findByID(int ID) {
        return employees.get(ID);
    }

    private Node<Integer> findNode(Node<Integer> currentNode, int key) {
        if (currentNode == null) {
            return null;
        }
        if (currentNode.getData().equals(key)) {
            return currentNode;
        }
        for (Node<Integer> child : currentNode.getChildren()) {
            Node<Integer> result = findNode(child, key);
            if (result != null) {
                return result;
            }
        }
        return null;
    }

    private Node<Integer> findLCA(Node<Integer> currentNode, int a, int b) {
        if (currentNode == null || currentNode.getData().equals(a) || currentNode.getData().equals(b)) {
            return currentNode;
        }

        Node<Integer> lca = null;
        for (Node<Integer> child : currentNode.getChildren()) {
            Node<Integer> temp = findLCA(child, a, b);
            if (temp != null) {
                if (lca != null) {
                    return currentNode; // Found LCA
                }
                lca = temp;
            }
        }
        return lca;
    }
}
