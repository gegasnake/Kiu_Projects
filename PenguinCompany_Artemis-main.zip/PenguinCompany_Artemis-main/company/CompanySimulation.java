package pgdp.company;

import java.util.Scanner;

public class CompanySimulation {
    public static void main(String[] args) {
        simulation("Novak", "ATP");
    }

    private static void simulation(String ceoName, String companyName) {
        Employee ceo = new Employee(ceoName, null);
        ceo.setID(0);
        Company company = new Company(companyName, ceo);
        Scanner scanner = new Scanner(System.in);
        String numberOfQueries = scanner.nextLine();

        for (int k = 0; k < Integer.parseInt(numberOfQueries); k++) {
            String query = scanner.nextLine();
            processQuery(query, company);
        }
        scanner.close();
    }

    private static void processQuery(String query, Company company) {
        String[] tokens = query.split(" ");
        String command = tokens[0].toLowerCase();

        switch (command) {
            case "employeewithid":
                int idToFind = Integer.parseInt(tokens[1]);
                Employee foundEmployee = company.findByID(idToFind);
                if (foundEmployee != null) {
                    System.out.println(foundEmployee);
                } else {
                    System.out.println("Employee not found.");
                }
                break;

            case "add":
                String name = tokens[1];
                int bossID = Integer.parseInt(tokens[2]);
                Employee boss = company.findByID(bossID);
                if (boss != null) {
                    Employee newEmployee = new Employee(name, boss);
                    company.addEmployee(newEmployee);
                } else {
                    System.out.println("Boss doesn't exist.");
                }
                break;

            case "fire":
                int idToFire = Integer.parseInt(tokens[1]);
                company.fireEmployee(idToFire);
                break;

            case "findcommonboss":
                int id1 = Integer.parseInt(tokens[1]);
                int id2 = Integer.parseInt(tokens[2]);
                Employee e1 = company.findByID(id1);
                Employee e2 = company.findByID(id2);
                if (e1 != null && e2 != null) {
                    Employee commonBoss = company.findCommonBoss(e1, e2);
                    System.out.println(commonBoss);
                } else {
                    System.out.println("Employee not found.");
                }
                break;

            default:
                System.out.println("Invalid command.");
                break;
        }
    }
}
