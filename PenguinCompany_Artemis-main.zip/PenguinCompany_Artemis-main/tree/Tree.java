package pgdp.tree;

import java.util.LinkedList;
import java.util.Queue;

public class Tree<T> {

    private Node<T> root;

    public Tree(T data) {
        root = new Node<>(data);
    }

    public void insert(T value, T parentValue) {
        if (value == null || containsKey(value) || parentValue == null || !containsKey(parentValue)) {
            return;
        }

        Node<T> parent = findNode(root, parentValue);
        if (parent != null) {
            Node<T> newNode = new Node<>(value);
            parent.insert(newNode);
        }
    }

    public void remove(T value) {
        if (value == null || value.equals(root.getData())) {
            return;
        }

        Node<T> nodeToRemove = findNode(root, value);
        if (nodeToRemove != null) {
            Node<T> parent = nodeToRemove.getParent();
            if (parent != null) {
                parent.removeChild(nodeToRemove);
            }
        }
    }

    public T LCA(T a, T b) {
        Node<T> lcaNode = findLCA(root, a, b);
        return (lcaNode != null) ? lcaNode.getData() : null;
    }

    public int distanceBetweenNodes(T a, T b) {
        Node<T> lcaNode = findLCA(root, a, b);
        if (lcaNode != null) {
            int distanceA = findDistance(lcaNode, a, 0);
            int distanceB = findDistance(lcaNode, b, 0);
            return distanceA + distanceB;
        }
        return 0;
    }

    public boolean containsKey(T key) {
        return findNode(root, key) != null;
    }

    public void traversal() {
        traverse(root);
    }

    private void traverse(Node<T> node) {
        if (node != null) {
            System.out.print(node.getData() + " ");
            for (Node<T> child : node.getChildren()) {
                traverse(child);
            }
        }
    }

    private Node<T> findNode(Node<T> currentNode, T key) {
        if (currentNode == null) {
            return null;
        }
        if (currentNode.getData().equals(key)) {
            return currentNode;
        }
        for (Node<T> child : currentNode.getChildren()) {
            Node<T> result = findNode(child, key);
            if (result != null) {
                return result;
            }
        }
        return null;
    }

    private Node<T> findLCA(Node<T> currentNode, T a, T b) {
        if (currentNode == null || currentNode.getData().equals(a) || currentNode.getData().equals(b)) {
            return currentNode;
        }

        Node<T> lca = null;
        for (Node<T> child : currentNode.getChildren()) {
            Node<T> temp = findLCA(child, a, b);
            if (temp != null) {
                if (lca != null) {
                    return currentNode; // Found LCA
                }
                lca = temp;
            }
        }
        return lca;
    }

    private int findDistance(Node<T> currentNode, T target, int distance) {
        if (currentNode == null) {
            return -1;
        }
        if (currentNode.getData().equals(target)) {
            return distance;
        }
        for (Node<T> child : currentNode.getChildren()) {
            int childDistance = findDistance(child, target, distance + 1);
            if (childDistance != -1) {
                return childDistance;
            }
        }
        return -1;
    }

    public Node<T> getRoot() {
        return root;
    }
}
