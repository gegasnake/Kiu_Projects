package pgdp.penguinDate;

import pgdp.tree.Node;
import pgdp.tree.Tree;

public class PenguinDateGenerator {

    private Tree<Penguin> tree;

    public PenguinDateGenerator(Tree<Penguin> tree) {
        this.tree = tree;
    }

    public boolean canGoOnADate(Penguin p1, Penguin p2) {
       Penguin Lca = tree.LCA(p1, p2);

       if (Lca == null) {
           return false;
       }

       int distance1 = tree.distanceBetweenNodes(p1, Lca);
       int distance2 = tree.distanceBetweenNodes(p2, Lca);
       return distance1 >= p1.getAllowance() && distance2 >= p2.getAllowance();

    }

    public Tree<Penguin> getTree() {
        return this.tree;
    }

}
