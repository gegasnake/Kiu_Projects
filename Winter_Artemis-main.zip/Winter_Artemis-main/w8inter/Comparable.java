package fop.w8inter;


public interface Comparable {
    int compareTo(Penguin other);
}
