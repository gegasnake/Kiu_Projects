package fop.w8inter;


public interface Copyable {

    Penguin copy();
}
