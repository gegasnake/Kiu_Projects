package fop.w8inter;

public class EmptyClass {
    // This class is only meant to show where your classes should be filed
    // and thus can be deleted.
}
