package fop.w8inter;

import java.util.Objects;

public class Penguin extends Animal implements Comparable, Copyable {
    private String name;
    private double height;

    Penguin(String name, double height, int age){
        super(age);
        this.name = name;
        this.height = height;
    }

    @Override
    public int compareTo(Penguin other) {
        if (this.getAge() == other.getAge()){
            if (this.height == other.height){
                if(Objects.equals(this.name, other.name)){
                    return 0;
                }else if(this.name.compareTo(other.name) > 0){
                    return 1;
                }else{
                    return -1;
                }
            } else if (this.height > other.height) {
                return 1;
            }else{
                return -1;
            }
        }else if(this.getAge() > other.getAge()){
            return 1;
        }else{
            return -1;
        }

    }

    @Override
    public Penguin copy() {

        return new Penguin(this.name, this.height, this.getAge());
    }

    public double getHeight() {
        return height;
    }

    public String getName() {
        return name;
    }
}
