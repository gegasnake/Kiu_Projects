package fop.w8inter;

public abstract class Animal {
    private int age;
    void birthday(){
        age++;
    }

    public Animal(int age){

        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
