public class Main {
    public static void main(String[] args) {
        IntDoubleList list = new IntDoubleList();
        list.append(5);
        list.append(10);
        System.out.println(list);
    }
}