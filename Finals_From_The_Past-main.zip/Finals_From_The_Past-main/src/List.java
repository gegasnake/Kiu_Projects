import java.util.Iterator;

public class List<T> implements Iterable<T>{
    T value;
    List<T> next;

    public List(T value, List<T> next){
        this.value = value;
        this.next = next;
    }

    public List(T value){
        this.value = value;
        this.next = null;
    }


    @Override
    public Iterator<T> iterator() {
        return new ListIterator<>(this);
    }

    static class ListIterator<T> implements Iterator<T>{
        private List<T> current;
        public ListIterator(List<T> current){
            this.current = current;
        }

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public T next() {
            List<T> temp = current;
            current = current.next;
            return temp.value;
        }
    }

    public static void main(String[] args) {
        List<Integer> list = new List<>(1);
        list.next = new List<>(2);
        list.next.next = new List<>(3);
        for (Integer i: list){
            System.out.println(i);
        }
    }
}