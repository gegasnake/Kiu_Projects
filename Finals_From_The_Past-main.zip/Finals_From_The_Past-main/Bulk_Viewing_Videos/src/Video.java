import java.util.List;

public interface Video {
    String title();
    void view();
    void skip();

}
