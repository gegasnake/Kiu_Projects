import java.io.IOException;
import java.util.*;
import java.util.List;
import java.util.function.*;
import java.util.stream.*;
import java.nio.file.*;

public class KiuFlix<V extends Video> {
    Stream<V> streams;
    List<V> downloads;
    int budget;
    int cost;

    public KiuFlix(Stream<V> streams, int budget, int cost) {
        this.streams = streams;
        this.downloads = new LinkedList<>();
        this.budget = budget;
        this.cost = cost;
    }

    public void bulkView(Predicate<V> predicate){
        streams.filter(predicate).limit(budget / cost).forEach(downloads::add);

        downloads.forEach(video -> {
            video.view();
            this.budget -= this.cost;
        });


        System.out.println("\nRemaining budget:\t" + this.budget);
    }


    public static void main(String[] args) throws IOException {
        String filename =  args[0];
        class MyVideo implements Video{
            String title;

            public MyVideo(String title) {
                this.title = title;
            }

            @Override
            public String title() {
                return title;
            }

            @Override
            public void view() {
                System.out.println(title);
            }

            @Override
            public void skip() {}
        }

        Stream<MyVideo> videoStream = null;
        try {
            videoStream = Files.lines(Path.of(filename)).map(MyVideo::new);
        } catch (IOException e) {
            System.out.println("Error reading titles from a file");
        }

        KiuFlix<MyVideo> flix = new KiuFlix<>(videoStream, 100, 15);

        flix.bulkView(video -> video.title.length() % 4 == 1);
    }


}
