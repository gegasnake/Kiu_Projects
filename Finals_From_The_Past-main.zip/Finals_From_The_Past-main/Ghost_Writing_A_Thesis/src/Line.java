public class Line<T extends Thesis> {
    private String content;
    private State state;
    private Thread[] writers;

    public Line(T ghost, String title) {
        this.content = title;
        this.state = State.INTRO;

        // create a thread array
        this.writers = new Thread[5];

        // assign each thread a part of thesis as a task
        this.writers[0] = new Thread(() -> processPart(ghost.intro(), State.INTRO, State.SETUP));
        this.writers[1] = new Thread(() -> processPart(ghost.setup(), State.SETUP, State.EXPERIMENTS));
        this.writers[2] = new Thread(() -> processPart(ghost.experiments(), State.EXPERIMENTS, State.CONCLUSION));
        this.writers[3] = new Thread(() -> processPart(ghost.conclusion(), State.CONCLUSION, State.REFS));
        this.writers[4] = new Thread(() -> processPart(ghost.refs(), State.REFS, State.FINISHED));
        // run all threads
        for (Thread writer: writers)
            writer.start();
    }

    private synchronized void processPart(String result, State fromState, State toState) {
        while (this.state != fromState) {
            try {
                wait();
            } catch (InterruptedException e) {}
        }

        this.content += result;
        this.state = toState;
        notifyAll();
    }

    public synchronized String result() {
        while (this.state != State.FINISHED) {
            try {
                wait();
            } catch (InterruptedException e) {}
        }
        return this.content;
    }

    public static void main(String[] args) {
        Thesis MyThesis = new Thesis() {

            @Override
            public String intro() {

                return args[1];
            }

            @Override
            public String setup() {
                return args[2];
            }

            @Override
            public String experiments() {
                return args[3];
            }

            @Override
            public String conclusion() {
                return args[4];
            }

            @Override
            public String refs() {
                return args[5];
            }
        };

        Line<Thesis> l = new Line<>(MyThesis, args[0]);

        System.out.println(l.result());
    }
}