public class Bistro {
    private int seats;
    private Thread order, meal, waiter;

    public Bistro(int n) {
        this.seats = n;

        this.waiter = new Thread(this::serve);
        this.waiter.setDaemon(true);
        this.waiter.start();
    }

    public synchronized void dine(int price) {
        while (seats == 0) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        } // wait until a seat is free

        this.seats--; // occupy a seat

        while (order != null) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }

        this.order = Thread.currentThread();
        System.out.println("Guest " + this.order.getId() + " orders for " + price + "Lari");
        notifyAll();


        while (this.meal != Thread.currentThread()) {
            try {
                wait();
            } catch (InterruptedException e) {} // wait for order
        }

        this.meal = null;
        notifyAll();

        System.out.println("Guest " + Thread.currentThread().getId() + " eats ...");

        this.seats++;
        notifyAll();
    }

    private synchronized void serve() {
        while (!waiter.isInterrupted()) { // interrupt is invoked from shutdown()
            while (this.order == null) {
                try {
                    wait();
                } catch (InterruptedException e) {
                } // wait for order
            }

            this.meal = this.order;
            this.order = null;
            notifyAll();


            System.out.println("Enjoy!");
            while (this.meal != null) {
                try {
                    wait();
                } catch (InterruptedException e) {
                } // wait for delivery
            }
        }
    }

    public void shutdown() {
        waiter.interrupt();
        System.out.println("Shut down!");
    }

}