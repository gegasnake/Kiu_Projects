public final class Leaf<T> implements Node<T>{
    private T value;
    public Leaf(T value){
        this.value= value;
    }
    public int size() {
        if(value==null)return 0;

        return 1;

    }
    public T get(int i) {
        if(i == 0){
            return value;
        }else {
            throw new IndexOutOfBoundsException();
        }
    }
    public void update(int i, T value) {
        if(i==0){
            this.value = value;
        }else {
            throw new IndexOutOfBoundsException();
        }
    }


    public Node<T> insert(int i, T value) {
        if (this.value==null){
            this.value=value;
        }
        if(i<=0){
            return new Inner<T>(new Leaf<T>(value),this);
        }else{
            return new Inner<T>(this,new Leaf<T>(value));
        }
    }


    public Node<T> remove(int i) {
        if(i==0){
            return null;
        }else{
            throw new IndexOutOfBoundsException();
        }
    }

    public T getValue() {
        return value;
    }
}