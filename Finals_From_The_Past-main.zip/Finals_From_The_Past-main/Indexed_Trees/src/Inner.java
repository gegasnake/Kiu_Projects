public final class Inner<T> implements Node<T> {
    private Node<T> left;
    private Node<T> right;
    int lSize;
    int rSize;

    public Inner(Node<T> left, Node<T> right) {
        this.left = left;
        this.right = right;

        this.lSize = left.size();
        this.rSize = right.size();
    }

    public int size() {
        return lSize + rSize;
    }
    public T get(int i) {
        if (i >= left.size()) {
            return right.get(i - left.size());
        } else {
            return left.get(i);
        }
    }
    public void update(int i, T value) {
        if (i >= left.size()) {
            right.update(i - left.size(), value);
        }else {
            left.update(i, value);
        }
    }
    public Node<T> insert(int i, T value) {
        if (0 <= i && i <= size()) {
            if (i >= left.size()) {
                right = right.insert(i - left.size(), value);
                rSize++;
            } else {
                left = left.insert(i, value);
                lSize++;
            }
        }else if(i<0) {
            this.insert(0, value);
            lSize++;
        }else if(i> size()) {
            this.insert(size(), value);
            rSize++;
        }
        return this;
    }
    public Node<T> remove(int i) {
        if((i+1)> left.size()){
            right = right.remove(i- left.size());
        }else{
            left = left.remove(i);
        }
        return this;
    }
}