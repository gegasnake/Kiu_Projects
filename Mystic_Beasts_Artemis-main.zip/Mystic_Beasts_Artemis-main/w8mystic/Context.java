package fop.w8mystic;

import java.util.Date;
import java.util.List;

public class Context {
    private SortStrategy sortStrategy;

    public Context(SortStrategy sortStrategy) {
        this.sortStrategy = sortStrategy;
    }

    public void setSortStrategy(SortStrategy sortStrategy) {
        this.sortStrategy = sortStrategy;
    }

    public void performSort(List<Date> input) {
        sortStrategy.performSort(input);
    }
}
