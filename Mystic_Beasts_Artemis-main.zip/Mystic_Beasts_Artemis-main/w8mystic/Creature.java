package fop.w8mystic;


public interface Creature {
    void eat();

    default String getClassName() {
        return "Creature";
    }
}

interface Bird extends Creature {
    void fly();

    default String getClassName() {
        return "Bird";
    }
}

interface Monster extends Creature {
    void breathFire();

    default String getClassName() {
        return "Monster";
    }
}

interface Flying extends Bird {
    default String getClassName() {
        return "Flying";
    }
}

class SimplePenguin implements Bird {
    @Override
    public void eat() {
        System.out.println("Penguin eats.");
    }

    @Override
    public void fly() {
        // Penguins can't fly
        System.out.println("Penguin can't fly.");
    }

    @Override
    public String getClassName() {
        return "SimplePenguin";
    }
}

class SimpleDragon implements Flying, SimpleFireBreathable {
    @Override
    public void eat() {
        System.out.println("Dragon eats.");
    }

    @Override
    public void fly() {
        System.out.println("Dragon flies.");
    }

    @Override
    public void breathFire() {
        System.out.println("Dragon breathes fire.");
    }

    @Override
    public String getClassName() {
        return "SimpleDragon";
    }
}
