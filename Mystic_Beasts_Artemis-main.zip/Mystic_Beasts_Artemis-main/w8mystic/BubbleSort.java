package fop.w8mystic;

import java.util.Date;
import java.util.List;

public class BubbleSort implements SortStrategy {

    @Override
    public void performSort(final List<Date> input) {
        // Bubble Sort implementation
        int n = input.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (input.get(j).compareTo(input.get(j + 1)) > 0) {
                    // Swap elements if they are in the wrong order
                    Date temp = input.get(j);
                    input.set(j, input.get(j + 1));
                    input.set(j + 1, temp);
                }
            }
        }
    }
}
