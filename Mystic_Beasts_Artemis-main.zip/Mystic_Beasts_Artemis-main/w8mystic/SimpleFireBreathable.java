package fop.w8mystic;
import java.util.Date;

public interface SimpleFireBreathable{

    public void eat();

    public void breathFire();

    public String getClassName();
}
