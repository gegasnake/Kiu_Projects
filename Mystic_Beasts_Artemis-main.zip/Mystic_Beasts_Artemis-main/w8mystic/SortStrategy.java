package fop.w8mystic;


import java.util.Date;
import java.util.List;

public interface SortStrategy {
    void performSort(List<Date> input);
}
