package fop.w8mystic;

import java.util.List;

public class Policy {
    // We use Bubble sort in this instance.
}
