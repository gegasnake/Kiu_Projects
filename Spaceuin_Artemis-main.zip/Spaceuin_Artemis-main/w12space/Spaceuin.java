package fop.w12space;

public class Spaceuin extends Thread {

    // TODO

    public Spaceuin(Beacon start, Beacon destination, FlightRecorder flightRecorder) {
        // TODO
    }

    // TODO

    @Override
    public String toString() {
        // changing that might be useful for testing
        return super.toString();
    }
}
