package fop.w12space;

public enum ConnectionType {
    NORMAL, WORMHOLE;
}
