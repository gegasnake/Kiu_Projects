public class RgbaColor extends RgbColor{
    private int alpha;

    RgbaColor(int bitDepth, int red, int green, int blue, int alpha) throws ColorException, Transparency {
        super(bitDepth, red, green, blue);
        if (alpha >= 0 && alpha < Math.pow(2, bitDepth)){
            this.alpha = alpha;
        }else{
            throw new Transparency("The number of Transparency is out of bounds.");
        }

    }

    @Override
    public RgbColor8Bit toRgbColor8Bit() throws ColorException {
        if (alpha != Math.pow(2, getBitDepth() - 1)){
            ExceptionUtil.unsupportedOperation("Alpha is not maximal");
        } else{
            if (getBitDepth() == 8){
                return new RgbColor8Bit(getRed(), getGreen(), getBlue());
            }
            int red8Bit = convertValueTo8Bit(getRed());
            int green8Bit = convertValueTo8Bit(getGreen());
            int blue8Bit = convertValueTo8Bit(getBlue());
            return new RgbColor8Bit(red8Bit, green8Bit, blue8Bit);
        }
        return new RgbColor8Bit(0, 0, 0);
    }

    final int getAlpha() {
        return alpha;
    }

    public String toString() {
        return "Red: " + getRed() + " Green: " + getGreen() + " Blue: " + getBlue() + " Transparency: " + getAlpha();
    }
}
