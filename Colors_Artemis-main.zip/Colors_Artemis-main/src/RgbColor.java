public class RgbColor {
    private final int red;
    private final  int blue;
    private final int green;

    private final int bitDepth;

    public RgbColor(int bitDepth, int red, int green, int blue) throws ColorException {
        if (bitDepth > 0 && bitDepth <= 31){
            this.bitDepth = bitDepth;
        }else{
            throw new ColorException("The bitDepth is out of bounds");
        }
        if (red >= 0 && green >= 0 && blue >= 0 && red < Math.pow(2, bitDepth) && green < Math.pow(2, bitDepth) && blue < Math.pow(2, bitDepth)){
            this.red = red;
            this.blue = blue;
            this.green = green;
        }else{
            throw new ColorException("The colour number is out of bounds");
        }

    }


    final int getBlue() {
        return blue;
    }

    final int getGreen() {
        return green;
    }

    final int getRed() {
        return red;
    }

    final int getBitDepth(){
        return bitDepth;
    }

    public RgbColor8Bit toRgbColor8Bit() throws ColorException {
        if (bitDepth == 8){
            return new RgbColor8Bit(red, green, blue);
        }
        int red8Bit = convertValueTo8Bit(red);
        int green8Bit = convertValueTo8Bit(green);
        int blue8Bit = convertValueTo8Bit(blue);
        return new RgbColor8Bit(red8Bit, green8Bit, blue8Bit);
    }

    protected int convertValueTo8Bit(int val){
        if (bitDepth > 8){
            int newVal = val / IntMath.powerOfTwo(bitDepth - 9);
            return Math.min(newVal / 2 + newVal % 2, IntMath.powerOfTwo(8) - 1);
        }
        if (bitDepth < 8){
            int newVal = val;
            int left = 8 - bitDepth;
            while(left != 0){
                int shift = Math.min(bitDepth, left);
                newVal = newVal * IntMath.powerOfTwo(shift) + val/IntMath.powerOfTwo(bitDepth - shift);
                left -= shift;
            }
            return newVal;
        }
        return val;
    }

    @Override
    public String toString() {
        return "Red: " + getRed() + " Green: " + getGreen() + " Blue: " + getBlue();
    }

    public static void main(String[] args) throws ColorException, Transparency {
        RgbColor color = new RgbColor(1, 1, 1, 1);
        System.out.println(color);

        RgbaColor color1 = new RgbaColor(1, 1, 1, 1, 1);
        System.out.println(color1);

        RgbColor8Bit color2 = new RgbColor8Bit(8, 8, 8);
        System.out.println(color2);
    }
}

class ColorException extends Exception {

    public ColorException(String message) {
        super(message);
    }

}

class Transparency extends Exception {

    public Transparency(String message) {
        super(message);
    }

}