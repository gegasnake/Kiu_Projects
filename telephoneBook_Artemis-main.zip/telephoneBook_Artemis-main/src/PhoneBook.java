public class PhoneBook extends MiniJava{
    private Entry[] entries;

    public PhoneBook(Entry[] entries){
        this.entries = entries;
    }

    public String find(String firstName, String lastName){
        int left = 0;
        int right = entries.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            Entry midEntry = entries[mid];

            int nameComparison = compareNames(firstName, lastName, midEntry);

            if (nameComparison == 0) {
                return midEntry.getPhoneNumber(); // Entry found, return phone number
            } else if (nameComparison < 0) {
                right = mid - 1; // Target is in the left half
            } else {
                left = mid + 1; // Target is in the right half
            }
        }

        return null; // Entry not found
    }

    private int compareNames(String firstName, String lastName, Entry entry) {
        int firstNameComparison = firstName.compareTo(entry.getFirstName());
        if (firstNameComparison != 0) {
            return firstNameComparison;
        }
        return lastName.compareTo(entry.getLastName());
    }
}
