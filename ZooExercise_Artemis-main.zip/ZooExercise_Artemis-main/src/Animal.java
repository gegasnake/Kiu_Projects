public class Animal extends MiniJava{
    private int foodCosts;
    private String name;

    public Animal(String name, int foodCosts){
        this.foodCosts = foodCosts;
        this.name = name;
    }

    public int get_foodCosts(){
        return foodCosts;
    }

    public String get_name(){
        return name;
    }

    @Override
    public String toString() {
        return "(name: " + this.name + ", foodCosts: " + this.foodCosts + ")";
    }
}

