import java.util.Arrays;

public class Zoo extends MiniJava{
    private Vivarium[] vivaria;

    public Zoo(Vivarium[] vivaria){
        this.vivaria = vivaria;
    }

    @Override
    public String toString() {
        return "{" + Arrays.toString(vivaria) + "}";
    }

    public int getCosts(){
        int all_vivarium_costs = 0;
        for (int i = 0; i < vivaria.length; i++){
            all_vivarium_costs += vivaria[i].getCosts();
        }
        return  all_vivarium_costs;


    }
}
