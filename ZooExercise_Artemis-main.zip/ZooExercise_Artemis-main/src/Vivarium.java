import java.util.Arrays;

public class Vivarium extends MiniJava{
    private int area;
    private int constructionYear;
    private Animal[] inhabitants;

    public Vivarium(Animal[] inhabitants, int area, int constructionYear){
        this.inhabitants = inhabitants;
        this.area = area;
        this.constructionYear = constructionYear;
    }

    @Override
    public String toString() {
        return "[area: " + this.area + ", constructionYear: " + this.constructionYear + ", animals: " +
                Arrays.toString(this.inhabitants) + "]";
    }

    public int getCosts(){
        int full_cost = 0;
        for (int i = 0; i < inhabitants.length; i++){
            full_cost += inhabitants[i].get_foodCosts();
        }
        //  900 + area in square meters * 100 + area in square meters * (2021 - year of construction) * 5
        full_cost += 900 + this.area * 100 + 100 * (2021 - this.constructionYear) * 5;
        return full_cost;
    }
}
