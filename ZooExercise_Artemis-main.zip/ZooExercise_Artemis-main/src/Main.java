public class Main {
    public static void main(String[] args) {
        Animal kangaroo = new Animal("kenny", 50);
        Animal lion = new Animal("chester", 100);
        Animal shark = new Animal("kutala", 500);
        System.out.println(kangaroo.get_foodCosts());
        System.out.println(kangaroo.get_name());
        System.out.println(kangaroo);

        Animal[] animal_array = new Animal[]{kangaroo, lion, shark};


        Vivarium sexalia = new Vivarium(animal_array, 100, 1989);
        Vivarium[] vivarium_array = new Vivarium[]{sexalia};
        Zoo bidzinas_samflobelo = new Zoo(vivarium_array);
        System.out.println(sexalia);
        System.out.println(bidzinas_samflobelo);
        System.out.println(sexalia.getCosts());
        System.out.println(bidzinas_samflobelo.getCosts());
    }
}