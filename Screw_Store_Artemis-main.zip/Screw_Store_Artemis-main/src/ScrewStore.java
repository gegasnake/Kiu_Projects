import java.util.*;
import java.util.stream.Collectors;

public class ScrewStore {

    private HashMap<Screw, Integer> stock;
    private LinkedList<Order> orders;

    public ScrewStore(HashMap<Screw, Integer> Stock, LinkedList<Order> orders){
        this.stock = Stock;
        this.orders = orders;
    }

    public ScrewStore(){
        this.stock = new HashMap<Screw, Integer>();
        this.orders = new LinkedList<Order>();
    }

    public void addItem(Screw type, int amount) {
        if (getStock().containsKey(type)){
            getStock().put(type, getStock().get(type) + amount);
        }else{
            getStock().put(type, amount);
        }
    }

    public void takeOrder(Screw type, int amount) {
        if (amount > 0){
            Order order = new Order(type, amount);
            orders.add(order);
        }
    }

    public boolean executeOrder() {
        if (orders.isEmpty()){
            return false;
        }
        Order order = orders.getFirst();
        Integer amount = getStock().get(order.getScrew());
        if (amount != null){
            if (amount == order.getAmount()){
                getStock().remove(order.getScrew());
                return true;
            }
            if (amount > order.getAmount()){
                getStock().put(order.getScrew(), amount - order.getAmount());
                return true;
            }

        }
        return false;
    }

    public void inflation(double percent) {
        Screw[] array = stock.keySet().toArray(new Screw[0]);
        for (int i = 0; i < array.length; i++){
            stock.put(array[i], (int) (stock.get(array[i]) + stock.get(array[i]) * percent / 100));
        }
    }

    public int count() {
        int count = 0;
        Screw[] set = stock.keySet().toArray(new Screw[0]);
        for (int i = 0; i < set.length; i++){
            count += stock.get(set[i]);
        }
        return count;
    }


    public double value() {
        int value = 0;
        Screw[] set = stock.keySet().toArray(new Screw[0]);
        for (int i = 0; i < set.length; i++){
            value += (int) (stock.get(set[i]) * set[i].getPrice());
        }
        return value;
    }



    public String stockToString() {
        StringBuilder sb = new StringBuilder();
        Screw[] set = stock.keySet().toArray(new Screw[0]);
        for (int i = 0; i < set.length; i++){
            sb.append(set[i].toString());
        }
        return sb.toString();
    }

    public HashMap<Screw, Integer> getStock() {
        return stock;
    }

    public LinkedList<Order> getOrders() {
        return orders;
    }
}
