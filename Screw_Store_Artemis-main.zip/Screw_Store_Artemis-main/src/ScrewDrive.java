public enum ScrewDrive {
    SlotDrive("ჯიხური"),
    Cross("ჯავლა"),
    Hex("ჰექსა"),
    Torx("თორქსი");

    private final String georgianName;

    ScrewDrive(String georgianName) {
        this.georgianName = georgianName;
    }

    @Override
    public String toString() {
        return georgianName;
    }
}
