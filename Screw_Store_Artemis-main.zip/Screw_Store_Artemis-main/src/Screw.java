import java.io.File;

public class Screw {
    private final double diameter;
    private final double length;
    private double price;

    private final int constant = 17;

    final ScrewDrive head;

    public Screw(double diameter, double length, double price, ScrewDrive head) {
        this.diameter = diameter;
        this.length = length;
        this.price = price;
        this.head = head;
    }

    public ScrewDrive getHead() {
        return head;
    }

    public double getDiameter() {
        return diameter;
    }

    public double getLength() {
        return length;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public int hashCode() {
        int result = 0;
        result = 31 * constant + constant;
        result = (int) (31 * result + 69 * diameter + 41 * length + 10 * price);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Screw)) return false;
        Screw other = (Screw) obj;
        return head == other.head && diameter == other.diameter && length == other.length;

    }

    @Override
    public String toString() {
        return "Screw: diameter - " + diameter + " length - " + length + " head - " + head + " price - " + price;
    }
}

