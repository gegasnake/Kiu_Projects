import java.util.Arrays;
import java.util.Random;

public class BubbleSort {

    public static void main(String[] args){
        int[] array = new int[1000];
        Random random = new Random();
        for (int i = 0; i < array.length; i++){
            array[i] = random.nextInt(100000);
        }
        System.out.println(Arrays.toString(array));
        long time = System.currentTimeMillis();
        boolean swapped = true;
        while(swapped){
            swapped = false;
            for(int x = 0; x < array.length - 1; x++){
                if(array[x] > array[x + 1]){
                    swapped = true;
                    int temp = array[x];
                    array[x] = array[x + 1];
                    array[x + 1] = temp;
                }
            }
        }
        long end_time = System.currentTimeMillis();
        System.out.println(Arrays.toString(array));
        System.out.println(end_time - time);
    }
}
