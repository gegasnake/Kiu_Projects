import java.util.Arrays;
import java.util.Random;

public class selectionSort {

    public static void main(String[] args){
        int[] array = new int[10000];
        Random random = new Random();
        for (int i = 0; i < array.length; i++){
            array[i] = random.nextInt(100000);
        }
        System.out.println(Arrays.toString(array));
        long time = System.currentTimeMillis();
        SelectionSort(array);
        System.out.println(Arrays.toString(array));
        long end_time = System.currentTimeMillis();
        System.out.println(end_time - time);


    }

    private static void SelectionSort(int[] array){
        int length = array.length;
        for (int i = 0; i < length - 1; i++){
            int min = array[i];
            int indexOfMin = i;
            for(int j = i + 1; j < length; j++){
                if (array[j] < min){
                    min = array[j];
                    indexOfMin = j;
                    swap(array, i, indexOfMin);
                }
            }



        }
    }

    private static void swap(int[] array, int i, int indexOfMin){
        int temp = array[i];
        array[i] = array[indexOfMin];
        array[indexOfMin] = temp;
    }
}
