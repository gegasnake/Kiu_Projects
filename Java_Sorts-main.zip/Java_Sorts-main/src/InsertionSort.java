import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class InsertionSort {
    public static void main(String[] args){
        int[] array = new int[100];
        Random random = new Random();
        for (int i = 0; i < array.length; i++){
            array[i] = random.nextInt(10000);
        }
        System.out.println(Arrays.toString(array));
        InsertionSort(array);
        System.out.println(Arrays.toString(array));
    }


    public static void InsertionSort(int[] array) {
        for (int x = 1; x < array.length; x++){
            int temp = array[x];

            int j = x - 1;
            while(j >= 0 && array[j] > temp){
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = temp;
        }
    }
}
