public class Car extends MiniJava{
    private String brand;
    private LicensePlate licensePlate;
    static int chassisNumber;

    public Car(String brand, LicensePlate licensePlate){
        this.brand = brand;
        this.licensePlate = licensePlate;
        chassisNumber++;
    }

    public LicensePlate getLicensePlate() {
        return licensePlate;
    }

    public String getBrand() {
        return brand;
    }

    // Car <chassisNumber>: (Brand: <brand>, License Plate: <licensePlate>)


    @Override
    public String toString() {
        return "Car <" + chassisNumber + ">: (Brand: <" + this.brand + ">, License PLate: " + this.licensePlate + ")";
    }
}
