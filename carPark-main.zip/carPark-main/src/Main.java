public class Main {
    public static void main(String[] args) {
        LicensePlate licenseplate1 = new LicensePlate("995", "AABB", 5557);
        LicensePlate licenseplate2 = new LicensePlate("699", "AABc", 4141);
        Car car1 = new Car("sixiki", licenseplate1);
        Car car2 = new Car("soxali", licenseplate2);
        CarPark bidzinas_parkingi = new CarPark(41);
        bidzinas_parkingi.park(car1);
        bidzinas_parkingi.park(car2);
        System.out.println(car2);
        System.out.println(bidzinas_parkingi);
    }
}