public class CarPark extends MiniJava{
    private Car[] cars;

    public CarPark(int n){
        this.cars = new Car[n];
    }

    public int park(Car c){
        for(int i = 0; i < cars.length; i++){
            if (cars[i] == null){
                cars[i] = c;
                return i + 1;
            }
        }
        return -1;

    }

    public int search(LicensePlate lp){
        for (int i = 0; i < cars.length; i++){
            if(lp.isEqual(cars[i].getLicensePlate())){
                return i;
            }
        }
        return -1;
    }

    public Car driveOff(LicensePlate lp){
        for (int i = 0; i < cars.length; i++){
            if(lp.isEqual(cars[i].getLicensePlate())){
                Car car = cars[i];
                cars[i] = null;
                return car;
            }
        }
        return null;

    }

    @Override
    public String toString() {
        MiniJava.write("car park: \n");
        for (int i = 0; i < cars.length; i++){
            if(cars[i] == null){
                System.out.println("<" + i + ">: " + "[]\n" );;
            }else{
                System.out.println("<" + i + ">: " + cars[i].toString() + "[]\n");
            }
        }
        return null;
    }
}
