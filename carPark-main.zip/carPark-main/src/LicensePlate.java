public class LicensePlate extends MiniJava{
    private String regionalCode;
    private String letters;
    private int digits;

    public LicensePlate(String regionalCode, String letters, int digits){
        this.regionalCode = regionalCode;
        this.letters = letters;
        this.digits = digits;
    }

    public boolean isEqual(LicensePlate other){
        return (other.regionalCode + other.letters + other.digits).equals(regionalCode + letters + digits);
    }

    // <regionalCode>:<letters> <digits>

    @Override
    public String toString() {
        return "<" + this.regionalCode + ">:<" + this.letters + "> <" + this.digits + ">";
    }
}
