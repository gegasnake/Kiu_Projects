public class CountingBrackets {
    public static void main(String[] args) {
        String expression1 = "([]){([])}";
        String expression2 = "([)]";

        if (BracketStack.checkBraces(expression1)) {
            System.out.println(expression1 + " is correctly bracketed.");
        } else {
            System.out.println(expression1 + " is not correctly bracketed.");
        }

        if (BracketStack.checkBraces(expression2)) {
            System.out.println(expression2 + " is correctly bracketed.");
        } else {
            System.out.println(expression2 + " is not correctly bracketed.");
        }
    }
}

