import java.util.Stack;

public class BracketStack {
    private int maxSize;
    private int stackpointer;
    private char[] stack;

    public BracketStack(int maxSize) {
        this.maxSize = maxSize;
        this.stackpointer = -1;
        this.stack = new char[maxSize];
    }

    public boolean isEmpty() {
        return stackpointer == -1;
    }

    public boolean isFull() {
        return stackpointer == maxSize - 1;
    }

    public void push(char value) {
        if (isFull()) {
            System.out.println("Stack is full. Cannot push " + value);
        } else {
            stack[++stackpointer] = value;
        }
    }

    public char pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty. Cannot pop.");
            return '\0';
        } else {
            return stack[stackpointer--];
        }
    }

    public char peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty. Cannot peek.");
            return '\0';
        } else {
            return stack[stackpointer];
        }
    }

    public static boolean checkBraces(String input) {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);
            if (currentChar == '(' || currentChar == '[' || currentChar == '{') {
                stack.push(currentChar);
            } else if (currentChar == ')' || currentChar == ']' || currentChar == '}') {
                if (stack.isEmpty() || !matches(stack.pop(), currentChar)) {
                    return false;
                }
            }
        }

        return stack.isEmpty();
    }

    private static boolean matches(char open, char close) {
        return (open == '(' && close == ')') || (open == '[' && close == ']') || (open == '{' && close == '}');
    }
}
