public class List {
    public int info;
    public List next;

    public List(int x, List L){
        info = x;
        next = L;
    }

    public List(int x){
        info = x;
        next = null;
    }

    public void insert(int x){
        next = new List(x);

    }

    public void delete(){
        if (next != null){
            next = next.next;
        }
    }

    public static boolean isEmpty(List L){
        return L == null;
    }

    public static String toString(List L){
        if (isEmpty(L)){
            return "[]";
        }else{
            return L.toString();
        }
    }

    public static List array_to_list(int[] a){
        List result = null;
        for (int i = a.length - 1; i >= 0; i--){
            result = new List(a[i], result);
        }
        return result;
    }

    public int[] list_to_array(){
        List t = this;
        int n = length();
        int[] a = new int[n];
        for (int i = 0; i < n; i++){
            a[i] = t.info;
            t = t.next;
        }
        return a;
    }

    private int length(){
        int result = 1;
        for (List t = next; t != null; t = t.next){
            result++;
        }
        return result;
    }

    @Override
    public String toString() {
        String result = "[" + info;
        List t = next;
        while(t != null){
            result += ", " + t.info;
            t = t.next;

        }
        result += "]";
        return result;
    }
}
