public class ArrayListImplementation<T> {
    private static final int DEFAULT_CAPACITY = 10;
    private Object[] array;
    private int size;

    public ArrayListImplementation() {
        this.array = new Object[DEFAULT_CAPACITY];
        this.size = 0;
    }

    // Add an element to the end of the list
    public void add(T element) {
        ensureCapacity();
        array[size++] = element;
    }

    // Get the element at a specific index
    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        return (T) array[index];
    }

    // Remove the element at a specific index
    public void remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        System.arraycopy(array, index + 1, array, index, size - index - 1);
        size--;
    }

    // Get the size of the list
    public int size() {
        return size;
    }

    // Ensure the capacity of the array
    private void ensureCapacity() {
        if (size == array.length) {
            int newCapacity = array.length * 2;
            Object[] newArray = new Object[newCapacity];
            System.arraycopy(array, 0, newArray, 0, size);
            array = newArray;
        }
    }

    public static void main(String[] args) {
        ArrayListImplementation<Integer> list = new ArrayListImplementation<>();

        // Add elements to the list
        list.add(10);
        list.add(20);
        list.add(30);

        // Print the size of the list
        System.out.println("Size of the list: " + list.size());

        // Access elements by index
        System.out.println("Element at index 1: " + list.get(1));

        // Remove an element
        list.remove(1);

        // Print the size of the list after removal
        System.out.println("Size of the list after removal: " + list.size());
    }
}
