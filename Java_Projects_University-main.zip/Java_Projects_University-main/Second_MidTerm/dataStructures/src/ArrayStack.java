public class ArrayStack {
    private static final int DEFAULT_CAPACITY = 10;
    private int[] array;
    private int size;

    public ArrayStack() {
        this.array = new int[DEFAULT_CAPACITY];
        this.size = 0;
    }

    // Push operation
    public void push(int item) {
        if (size == array.length) {
            // If the array is full, double its size
            resizeArray();
        }
        array[size++] = item;
    }

    // Pop operation
    public int pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return array[--size];
    }

    // Peek operation
    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return array[size - 1];
    }

    // Check if the stack is empty
    public boolean isEmpty() {
        return size == 0;
    }

    // Get the size of the stack
    public int size() {
        return size;
    }

    // Helper method to resize the array when it's full
    private void resizeArray() {
        int newCapacity = array.length * 2;
        int[] newArray = new int[newCapacity];
        System.arraycopy(array, 0, newArray, 0, size);
        array = newArray;
    }

    public static void main(String[] args) {
        ArrayStack stack = new ArrayStack();

        // Push some elements onto the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Print the size of the stack
        System.out.println("Size of the stack: " + stack.size());

        // Peek at the top element
        System.out.println("Peek: " + stack.peek());

        // Pop elements from the stack
        System.out.println("Pop: " + stack.pop());
        System.out.println("Pop: " + stack.pop());

        // Print the size of the stack after popping
        System.out.println("Size of the stack: " + stack.size());

        // Check if the stack is empty
        System.out.println("Is the stack empty? " + stack.isEmpty());
    }
}
