import java.util.LinkedList;

public class ListStack<T> {
    private LinkedList<T> list;

    public ListStack() {
        this.list = new LinkedList<>();
    }

    // Push operation
    public void push(T item) {
        list.addLast(item);
    }

    // Pop operation
    public T pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return list.removeLast();
    }

    // Peek operation
    public T peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return list.getLast();
    }

    // Check if the stack is empty
    public boolean isEmpty() {
        return list.isEmpty();
    }

    // Get the size of the stack
    public int size() {
        return list.size();
    }

    public static void main(String[] args) {
        ListStack<Integer> stack = new ListStack<>();

        // Push some elements onto the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Print the size of the stack
        System.out.println("Size of the stack: " + stack.size());

        // Peek at the top element
        System.out.println("Peek: " + stack.peek());

        // Pop elements from the stack
        System.out.println("Pop: " + stack.pop());
        System.out.println("Pop: " + stack.pop());

        // Print the size of the stack after popping
        System.out.println("Size of the stack: " + stack.size());

        // Check if the stack is empty
        System.out.println("Is the stack empty? " + stack.isEmpty());
    }
}
