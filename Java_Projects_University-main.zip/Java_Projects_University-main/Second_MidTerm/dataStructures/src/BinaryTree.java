import java.util.LinkedList;
import java.util.Queue;

class TreeNode<T extends Comparable<T>> {
    T data;
    TreeNode<T> left;
    TreeNode<T> right;

    public TreeNode(T data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}

public class BinaryTree<T extends Comparable<T>> {
    private TreeNode<T> root;

    public BinaryTree() {
        this.root = null;
    }

    // Insertion
    public void insert(T data) {
        root = insertRecursive(root, data);
    }

    private TreeNode<T> insertRecursive(TreeNode<T> root, T data) {
        if (root == null) {
            return new TreeNode<>(data);
        }

        if (data.compareTo(root.data) < 0) {
            root.left = insertRecursive(root.left, data);
        } else if (data.compareTo(root.data) > 0) {
            root.right = insertRecursive(root.right, data);
        }

        return root;
    }

    // Searching
    public boolean search(T data) {
        return searchRecursive(root, data);
    }

    private boolean searchRecursive(TreeNode<T> root, T data) {
        if (root == null) {
            return false;
        }

        if (data.equals(root.data)) {
            return true;
        } else if (data.compareTo(root.data) < 0) {
            return searchRecursive(root.left, data);
        } else {
            return searchRecursive(root.right, data);
        }
    }

    // Deletion
    public void delete(T data) {
        root = deleteRecursive(root, data);
    }

    private TreeNode<T> deleteRecursive(TreeNode<T> root, T data) {
        if (root == null) {
            return null;
        }

        if (data.equals(root.data)) {
            // Node with only one child or no child
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            // Node with two children: Get the inorder successor (smallest
            // in the right subtree)
            root.data = minValue(root.right);

            // Delete the inorder successor
            root.right = deleteRecursive(root.right, root.data);
        } else if (data.compareTo(root.data) < 0) {
            root.left = deleteRecursive(root.left, data);
        } else {
            root.right = deleteRecursive(root.right, data);
        }

        return root;
    }

    private T minValue(TreeNode<T> root) {
        T minValue = root.data;
        while (root.left != null) {
            minValue = root.left.data;
            root = root.left;
        }
        return minValue;
    }

    // Traversals
    public void inOrderTraversal() {
        inOrderTraversalRecursive(root);
        System.out.println();
    }

    private void inOrderTraversalRecursive(TreeNode<T> root) {
        if (root != null) {
            inOrderTraversalRecursive(root.left);
            System.out.print(root.data + " ");
            inOrderTraversalRecursive(root.right);
        }
    }

    public void preOrderTraversal() {
        preOrderTraversalRecursive(root);
        System.out.println();
    }

    private void preOrderTraversalRecursive(TreeNode<T> root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preOrderTraversalRecursive(root.left);
            preOrderTraversalRecursive(root.right);
        }
    }

    public void postOrderTraversal() {
        postOrderTraversalRecursive(root);
        System.out.println();
    }

    private void postOrderTraversalRecursive(TreeNode<T> root) {
        if (root != null) {
            postOrderTraversalRecursive(root.left);
            postOrderTraversalRecursive(root.right);
            System.out.print(root.data + " ");
        }
    }

    public void levelOrderTraversal() {
        if (root == null) {
            return;
        }

        Queue<TreeNode<T>> queue = new LinkedList<>();
        queue.add(root);

        while (!queue.isEmpty()) {
            TreeNode<T> current = queue.poll();
            System.out.print(current.data + " ");

            if (current.left != null) {
                queue.add(current.left);
            }

            if (current.right != null) {
                queue.add(current.right);
            }
        }

        System.out.println();
    }

    public static void main(String[] args) {
        BinaryTree<Integer> tree = new BinaryTree<>();

        // Insert some values into the tree
        tree.insert(5);
        tree.insert(3);
        tree.insert(7);
        tree.insert(1);
        tree.insert(4);
        tree.insert(6);
        tree.insert(8);

        // Perform various traversals
        System.out.println("In-order traversal:");
        tree.inOrderTraversal();

        System.out.println("Pre-order traversal:");
        tree.preOrderTraversal();

        System.out.println("Post-order traversal:");
        tree.postOrderTraversal();

        System.out.println("Level-order traversal:");
        tree.levelOrderTraversal();

        // Search for a value
        System.out.println("Search for 4: " + tree.search(4));
        System.out.println("Search for 10: " + tree.search(10));

        // Delete a value and perform in-order traversal
        tree.delete(5);
        System.out.println("In-order traversal after deleting 5:");
        tree.inOrderTraversal();
    }
}
