public class Zombie extends Monster{
    public Zombie() {
        super(40, 1.0, "Rotten Flash", 2);
    }

    @Override
    public void makeSound(){
        System.out.println("GROAN!");
    }


}
