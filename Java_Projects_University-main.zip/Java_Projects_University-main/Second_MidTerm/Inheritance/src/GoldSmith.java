public class GoldSmith extends Villager{
    public GoldSmith() {
        super(100, 1.0, "GoldSmith");
    }

    public void craft(){
        System.out.println("crafting jewelry");
    }
}
