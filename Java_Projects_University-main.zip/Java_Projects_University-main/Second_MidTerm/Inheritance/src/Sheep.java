public class Sheep extends Animal{
    public Sheep() {
        super(25, 1.2, "Meat and Wool", true);
    }

    @Override
    public void makeSound(){
        System.out.println("Baaaaa!");
    }

    public void shave(){
        System.out.println("Shaving the sheep");
    }
}
