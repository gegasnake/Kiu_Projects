public class Inheritance {
    public static void main(String[] args){

    }
}
