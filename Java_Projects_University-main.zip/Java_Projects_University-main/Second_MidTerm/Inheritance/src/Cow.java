public class Cow extends Animal{
    public Cow() {
        super(30, 1.2, "Meat and Leather", true);
    }

    @Override
    public void makeSound(){
        System.out.println("Moooo");
    }

    public void milk(){
        System.out.println("Milking the cow");
    }
}
