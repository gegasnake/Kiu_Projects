package Function;

public interface Supplier<R> {
    R get();
}
