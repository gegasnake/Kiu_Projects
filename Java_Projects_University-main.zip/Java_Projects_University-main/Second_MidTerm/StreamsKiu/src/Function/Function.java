package Function;

public interface Function<T, R>{
    R apply(T arg);
}
