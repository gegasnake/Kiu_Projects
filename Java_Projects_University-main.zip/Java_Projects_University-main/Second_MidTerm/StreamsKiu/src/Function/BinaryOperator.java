package Function;

public interface BinaryOperator<T> {
    T apply(T arg1, T arg2);

}
