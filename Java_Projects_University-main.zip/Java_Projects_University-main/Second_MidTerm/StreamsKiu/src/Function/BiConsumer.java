package Function;

public interface BiConsumer<R, T> {
    void accept(R r, T t);
}
