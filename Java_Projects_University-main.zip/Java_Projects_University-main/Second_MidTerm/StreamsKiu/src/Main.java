import Stream.Stream;
import collection.List;
import iterator.Iterator;

public class Main {
    public static void main(String[] args) {
//        List<String> animalNames = Arrays.asList("lion", "tiger", "bear");
//        Stream<String> upperCaseAnimals = animalNames.stream().map(String::toUpperCase);
//        upperCaseAnimals.forEach(System.out::println);
//
//        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6);
//        Stream<Integer> even_numbers = numbers.stream().filter(e -> e % 2 == 0);
//        even_numbers.forEach(System.out::println);
//
//        List<Integer> numbers2 = Arrays.asList(1, 2, 3, 4, 5);
//        Optional<Integer> sum = numbers2.stream().reduce(Integer::sum);
//        sum.ifPresent(System.out::println);
        Stream<Integer> emptyStream = Stream.empty();
        System.out.println(emptyStream.eval());

        Stream<Integer> test = Stream.of(5);
        System.out.println(test.eval().getRest().eval());

        List<Integer> list = new List<>(1);
        list.next = new List<>(2);
        list.next.next = new List<>(3);
        list.next.next.next = new List<>(4);
//        Iterator<Integer> iterator = list.iterator();
//        while (iterator.hasNext()){
//            System.out.println(iterator.next());
//        }
        Stream<Integer> myStream = Stream.of(new Integer[] {1, 2, 3, 4});
        myStream.forEach(System.out::println);
        myStream.forEach(System.out::println);



    }
}