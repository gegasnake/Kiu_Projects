public class Functional_Interfaces_And_Lambda_Expressions {
    public static void main(String[] args){
        /*
        {argument list} -> {body}
        () {
        // code
        }
         */

        // Drawable test2 = () -> System.out.println("drawing");
        // test2.draw();

        Drawable test = (name) -> {
            System.out.println("draw " + name);
        };
        test.draw("Gega");
    }
}
