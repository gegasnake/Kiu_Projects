public interface Drawable{

    public void draw(String name);
}