import java.util.Optional;

class A{
    public void f(Object o, String s){
        System.out.println(1);
    }

}

class B extends A{
    public void f (String s, Object o){
        System.out.println(2);
    }
}


public class poly2 {
    public static void main(String[] args){
        A ab = new B();
        ab.f("", "");
    }
}
