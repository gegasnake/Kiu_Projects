import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

class LibraryItem {
    private static int nextId = 1;
    private final int id;
    private final String title;
    private boolean available;
    public LibraryItem(String title) {
        this.id = nextId++;
        this.title = title;
        this.available = true;
    }
    public int getId() {
        return id;
    }
    public String getTitle() {
        return title;
    }
    public boolean isAvailable() {
        return available;
    }public void setAvailable(boolean available) {
        this.available = available;
    }
    public void checkOut() {
        if (available) {
            available = false;
            System.out.println("Item checked out: " + getTitle());
        } else {
            System.out.println("Item is not available for checkout: " + getTitle());
        }
    }
    public void checkIn() {
        available = true;
        System.out.println("Item checked in: " + getTitle());
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LibraryItem that = (LibraryItem) o;
        return id == that.id;
    }
    @Override
    public int hashCode() {return title.hashCode() * 29 + id * 29 * 29;
    }
    @Override
    public String toString() {
        return "LibraryItem - ID: " + id + ", Title: " + title + ", Available: " + available;
    }
}
class Library<T extends LibraryItem> {
    private Map<Integer, T> itemMap;
    private Set<T> checkedOutItems;
    public Library() {
        this.itemMap = new HashMap<>();
        this.checkedOutItems = new HashSet<>();
    }
    public void addItem(T item) {
        itemMap.put(item.getId(), item);
    }
    public void removeItem(T item) {
        itemMap.remove(item.getId());
        checkedOutItems.remove(item);
    }
    public void displayAvailableItems() {
        System.out.println("Available Items:");for (T item : itemMap.values()) {
            if (item.isAvailable()) {
                System.out.println(item);
            }
        }
    }
    public void displayCheckedOutItems() {
        System.out.println("Checked Out Items:");
        for (T item : checkedOutItems) {
            System.out.println(item);
        }
    }
    public void checkOutItem(int itemId) {
        T item = itemMap.get(itemId);
        if (item != null && item.isAvailable()) {
            item.checkOut();
            checkedOutItems.add(item);
        } else {
            System.out.println("Item with ID " + itemId + " is not available for checkout.");
        }
    }
    public void checkInItem(int itemId) {
        T item = itemMap.get(itemId);
        if (item != null && !item.isAvailable()) {
            item.checkIn();
            checkedOutItems.remove(item);} else {
            System.out.println("Item with ID " + itemId + " is not checked out.");
        }
    }
}
class Book extends LibraryItem {
    private String author;
    public Book(String title, String author) {
        super(title);
        this.author = author;
    }
    public String getAuthor() {
        return author;
    }
    public String getAuthorInfo() {
        return "Author: " + author;
    }
    @Override
    public String toString() {
        return "Book - ID: " + getId() + ", Title: " + getTitle() + ", " + getAuthorInfo() + ", Available: " +
                isAvailable();
    }
}class DVD extends LibraryItem {
    private String director;
    public DVD(String title, String director) {
        super(title);
        this.director = director;
    }
    public String getDirector() {
        return director;
    }
    public String getDirectorInfo() {
        return "Director: " + director;
    }
    @Override
    public String toString() {
        return "DVD - ID: " + getId() + ", Title: " + getTitle() + ", " + getDirectorInfo() + ", Available: " +
                isAvailable();
    }
}