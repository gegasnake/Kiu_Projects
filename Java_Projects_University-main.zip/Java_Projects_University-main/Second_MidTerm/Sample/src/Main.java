public class Main {
    static class A{
        void f(A a){
            System.out.println("A.f(A a)");
        }
        void f(K<?> k){
            System.out.println("A.f(K<?> k)");
        }
    }

    static class B extends A{
        void f(A a){
            System.out.println("B.f(A a) ");
        }

        void f(B b){
            System.out.println("B.f(B b)");
        }
    }

    static class K<T extends A>{
        void f(T t){
            System.out.println("k.f(T t)");
            t.f(this);
        }
    }


    public static void main(String[] args) {
        A a = new A();
        A ab = new B();
        B b = new B();
        K<B> k = new K<>();

        //b.f(b);
        // b.f((B) a);
        //a.f(b);
        ab.f(b);
        //k.f(ab);
        //k.f(b);
        int x = 2000000000;
        int y = 100000000;
        enums myenum = enums.EARTH;
        System.out.println(myenum.getN());
        System.out.println(x + 10 > y + 10);

    }
}