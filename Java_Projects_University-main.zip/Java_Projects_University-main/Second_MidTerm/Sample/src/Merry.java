public class Merry<T>{
    public T data;
    public Merry<T> prev, next;

    public Merry(T t){
        this.data = t;
        next = prev =this;
    }

    public void join(Merry<T> merry){
        if (merry == null){
            return;
        }

        Merry<T> last = this.prev;
        this.prev = merry.prev;
        merry.prev.next = this;
        last.next = merry;
        merry.prev = last;

    }

    public static <T> Merry<T> reverse(Merry<T> merry){
        if (merry == null){
            return null;
        }

        if(merry.next == merry){
            return merry;
        }

        Merry<T> tmp = merry;
        Merry<T> next;
        do{
            next = tmp.next;
            tmp.next = tmp.prev;
            tmp.prev = next;
            tmp = next;
        }while(tmp != merry);
        return merry.next;
    }

    public static <T> Merry<T> merryOfArray(T[] arr){
        if (arr == null){
            return null;
        }
        if(arr.length == 0){
            return null;
        }

        Merry<T> merry = new Merry<T>(arr[0]);
        for(int i = 0; i < arr.length; i++){
            merry.join(new Merry<T>(arr[i]));
        }

        return merry;
    }

    public static void main(String[] args){
        Merry<Integer> I = merryOfArray(new Integer[]{1, 2, 3});
        System.out.println(I.data);
        System.out.println(I.next.data);
        System.out.println(I.next.next.data);
        System.out.println(I.next.next.next.data);
    }
}
