public class Doit {
    public static void main(String[] arr) {
        Work<String> work = new NoWork<>();
        for(String s: arr) work = work.addwork(s);
        for(String s: work.reverse()) System.out.println(s);
    }
}