enum enums {
    EARTH(1), PLUTO(2), JUPITER(3);
    private int n;

    enums(int n){
        this.n = n;
    }

    public int getN() {
        return n;
    }
}
