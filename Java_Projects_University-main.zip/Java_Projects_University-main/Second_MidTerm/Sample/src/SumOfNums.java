final class SumOfNums {
    private final int X;
    private final int Y;

    SumOfNums(int x1, int y) {
        this.X = x1;
        this.Y = y;
    }


    public int sum(){
        return getX() + getY();
    }

    public int getX() {
        return X;
    }

    public int getY() {
        return Y;
    }
}
