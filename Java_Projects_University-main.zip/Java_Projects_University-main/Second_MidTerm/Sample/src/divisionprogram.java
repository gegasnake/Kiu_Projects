public class divisionprogram {
    public static void main(String[] args){
        try {
            // Perform integer division
            int result = 10 / 0; // You can replace 10 and 0 with any integers
            // Print the result (this line will not be reached if an exception occurs)
            System.out.println("Result of division: " + result);

        } catch (ArithmeticException e) {
            // Catch arithmetic exceptions (e.g., division by zero)
            e.printStackTrace();
            System.out.println("Full Name: Full name"); // Replace with your actual full name
        } finally {
            // This block will always be executed
            System.out.println("KIU");
        }
    }

}
