import java.util.Iterator;

interface Work<T> extends Iterable<T> {
    boolean noWork();
    Work<T> addwork(T x);
    T viewWork();
    Work<T> removeWork();
    Work<T> reverse();
    default Iterator<T> iterator() {
        return new WorkIterator<T>(this);
    }
    class WorkIterator<T> implements Iterator<T> {
        private Work<T> l;
        public WorkIterator(Work<T> l) {
            this.l = l;
        }
        public boolean hasNext() {
            return !l.noWork();
        }
        public T next() {
            T result = l.viewWork();
            l = l.removeWork();
            return result;
        }
    }}
class NoWork<T> implements Work<T> {
    public NoWork() { }
    public boolean noWork() {
        return true;
    }
    public T viewWork() {
        throw new RuntimeException("No work!");
    }
    public Work<T> removeWork() {
        throw new RuntimeException("No work!");
    }
    public Work<T> addwork(T x) {
        return new SomeWork<T> (x,this);
    }
    public Work<T> reverse() {
        return new NoWork<T>();
    }
}
class SomeWork<T> implements Work<T> {
    public T data;
    public Work<T> next;
    public SomeWork(T x, Work<T> l) {
        data = x; next = l;
    }
    public boolean noWork() {return false;
    }
    public T viewWork() {
        return this.data;
    }
    public Work<T> removeWork() {
        return this.next;
    }
    public Work<T> addwork(T x) {
        return new SomeWork<T> (x,this);
    }
    public Work<T> reverse() {
        Work<T> result = new NoWork<T>();
        for(T t: this) result = new SomeWork<T>(t,result);
        return result;
    }
}