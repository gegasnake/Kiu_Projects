public class Cat extends Animal{
    public Cat(int age, String name) {
        super(age, name);
    }

    public void makeNoise(){
        System.out.println("Meow");
    }
}
