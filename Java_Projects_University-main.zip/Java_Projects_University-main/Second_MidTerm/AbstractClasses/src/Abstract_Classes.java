public class Abstract_Classes {
    public static void main(String[] args){
        Cat myCat = new Cat(5, "ksovro");
        myCat.makeNoise();
        myCat.printName();
    }
}
