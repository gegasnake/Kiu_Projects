interface I <T> {
    T foo();
    static <T> boolean batz(I<T> x){
        return x.foo() != null;
    }
    default String name(){
        if (batz(this)){
            return this.foo().toString();
        }else{
            return "Sorry";
        }
    }
}