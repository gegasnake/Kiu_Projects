import java.util.*;
import java.util.stream.Collectors;

public class StreamIntro {
    public static final Person p1 = new Person("Paul", 20);
    public static final Person p2 = new Person("Mia", 23);
    public static final Person p3 = new Person("Leo", 23);
    public static final Person p4 = new Person("Elias", 23);
    public static final Person p5 = new Person("Laura", 22);

    public static double calculate(List<Double> input) {

        double x = input.stream()
                .filter(in -> in > 0)
                .map(in -> in * in)
                .reduce(0.0, Double::sum);

        return x;
    }

    public static Set<Person> toSetForEach(List<Person> input) {
        Set<Person> result = new HashSet<>();
        input.stream()
                .forEach(in -> result.add(in));
        return result;
    }

    public static Set<Person> toSet(List<Person> input) {
        Set<Person> personSet= input.stream()
                .collect(Collectors.toSet());
        return personSet;
    }

    public static double average(int[] input) {
        double average =  Arrays.stream(input).
                                average()
                                .orElse(0.0);
        return average;
    }

    public static double averageAge(List<Person> input) {
        double average = input.stream()
                .mapToInt(Person::getAge)
                .average()
                .orElse(0.0);
        return average;
    }

    public static Map<Integer, List<Person>> groupByAgeForEach(
            List<Person> input) {
        Map<Integer, List<Person>> result = new HashMap<Integer, List<Person>>();
        input.stream()
                .forEach(in -> result
                        .computeIfAbsent(in.getAge(), k -> new ArrayList<>())
                        .add(in));


        return result;
    }

    public static Map<Integer, List<Person>> groupByAge(List<Person> input) {
        Map<Integer, List<Person>> x = input.stream().collect(Collectors.groupingBy(Person::getAge));
        return x;
    }

    public static void main(String[] args){

    }
}
