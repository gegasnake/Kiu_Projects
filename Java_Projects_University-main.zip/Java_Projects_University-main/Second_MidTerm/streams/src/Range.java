
public class Range {
    private double max, min;

    public void add(double x){
        if (this.max < x) {
            this.max = x;

        }
        if(this.min > x || this.min == 0.0){
            this.min = x;
        }
    }

    public void join(Range r){
        this.add(r.max);
        this.add(r.min);
    }

    public double getMax() {
        return max;
    }

    public double getMin() {
        return min;
    }

    public double diff(){
        return this.max - this.min;
    }

    public Range(){
        this.min = 0.0;
        this.max = 0.0;
    }
}
