import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RangeTest {
    public static void main(String[] args) throws IOException{
        BiConsumer<Range, Double> acc = Range::add;
        BiConsumer<Range, Range> comb = Range::join;

        Stream<String> ss = Files.lines(Path.of(args[0]));


    }
}
