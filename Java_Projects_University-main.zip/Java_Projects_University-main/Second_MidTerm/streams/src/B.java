public class B implements I<String>{
    private String story;

    public B(String story){
        this.story = story;
    }

    public String foo(){
        return this.story;
    }

    public static void main(String[] args){
        B b = new B(null);
        System.out.println(b.name());
        System.out.println(I.batz(b));
        Range x = new Range();

        x.add(5);
        x.add(10);
        System.out.println(x.getMax());
        System.out.println(x.getMin());
        x.add(20);
        System.out.println(x.getMax());
    }
}
