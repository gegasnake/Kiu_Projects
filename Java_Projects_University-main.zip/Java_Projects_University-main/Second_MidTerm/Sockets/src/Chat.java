import java.io.*;
import java.net.*;
import java.util.Scanner;


public class Chat {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while(true){
            printInstructions();

            String input = scanner.nextLine();

            if (input.equals("exit")){
                System.out.println("Exiting.");
                break;
            }

            if (input.contains(":")){
                startClient(input);
            }else{
                startServer(input);
            }
        }
    }


    private static void printInstructions(){
        System.out.println("Enter <port> to start the chat server \n " +
                            "or <host>:<port> to connect to a running server. \n" +
                            "Enter 'exit' to exit the chat.\n");
    }

    private static void startServer(String input){
        int port;
        try{
            port = Integer.parseInt(input.trim());
        }catch (NumberFormatException e){
            System.out.println("invalid port number");
            return;
        }

        try
            (ServerSocket serverSocket = new ServerSocket(port);
            Socket clientSocket = serverSocket.accept();
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            Scanner sc = new Scanner(System.in)){
            System.out.println("Client connected. Type 'exit' to quit.");
            handleChatSession(sc, in, out, "Client");
        }catch (IOException e){
            System.out.println("Server error: " + e.getMessage());
        }


    }

    private static void startClient(String input){
        String[] pair = input.trim().split(":");
        String host = pair[0];
        int port = Integer.parseInt(pair[1]);

        try(Socket client = new Socket(host, port);
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter out = new PrintWriter(client.getOutputStream(), true);
            Scanner sc = new Scanner(System.in);
        ){
            System.out.println("Connected to server. Type 'exit' to quit.");
            handleChatSession(sc, in, out, "Client");
        }catch (IOException e){
            System.out.println("Connection Error: " + e.getMessage());
        }
    }

    private static void handleChatSession(Scanner sc, BufferedReader in, PrintWriter out, String peerName) throws IOException{
        while (true){
            if (sc.hasNextLine()){
                String message = sc.nextLine();
                if (message.equalsIgnoreCase("exit")){
                    break;
                }

                out.println(message);
            }

            if (in.ready()){
                String response = in.readLine();
                if (response != null){
                    System.out.println(peerName + ": " + response);
                }
            }
        }

    }
}