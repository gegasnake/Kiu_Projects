class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class Main {

    public static void divide(int numerator, int denominator) throws CustomException {
        if (denominator == 0) {
            throw new CustomException("Cannot divide by zero.");
        }
        int result = numerator / denominator;
        System.out.println("Result of the division: " + result);
    }

    public static void main(String[] args) {
        try {
            divide(10, 2);
            divide(5, 0);
        } catch (CustomException e) {
            System.out.println("Custom Exception caught: " + e.getMessage());
        }
    }
}



