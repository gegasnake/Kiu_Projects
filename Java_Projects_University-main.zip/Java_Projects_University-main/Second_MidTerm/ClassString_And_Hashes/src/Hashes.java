import java.util.HashMap;
import java.util.HashSet;

public class Hashes{
    public static void main(String[] args){
        HashSet<String> Words = new HashSet<>();
        HashMap<String, String> Countries = new HashMap<>();

        // 1 2 3 4 5
        // Georgia: Tbilisi, United States: Washington, England: London, France: Paris
        // key: value
        Countries.put("Georgia", "Tbilisi");
        Countries.put("United States", "Washington");
        Countries.put("England", "London");
        Countries.put("France", "Paris");
        System.out.println(Countries);
        System.out.println(Countries.get("England"));
        System.out.println(Countries.containsKey("Poland"));

        Countries.clear();
        System.out.println(Countries);

    }
}