import java.util.HashSet;

public class AboutStrings {
    public static void main(String[] args){
        char[] data = new char[] {'G', 'a', 'm', 'a', 'r', 'j', 'o', 'b', 'a'};
        String str = new String(data);
        System.out.println(str);
        System.out.println(data);


        System.out.println("abc");
        String cde = "cde";
        System.out.println("abc"+cde);
        String c = "abc".substring(0,3);
        String d = cde.substring(1,2);
        System.out.println(c);
        System.out.println(d);

        //String();
        //String(char[] value);
        //String(String s);
        //String(StringBuffer buffer);

        String word = "Hello";
        System.out.println(word.charAt(2));

        String ab = "ab";
        String cd = "cd";
        System.out.println(cd.compareTo(ab));

        String a = "ak";
        String b = "ablk";
        System.out.println(a.equals(b));

        System.out.println(a.indexOf('a'));
        System.out.println(b.indexOf('k'));

        System.out.println(a.length());

        String text = "Hello World!";
        System.out.println(text.replace('o', 'V'));

        System.out.println(text.substring(2));
        System.out.println(text.substring(2, 9));

        System.out.println(text.toLowerCase());
        System.out.println(text.toUpperCase());

        String trim_text = "  Hello World!      f";
        System.out.println(trim_text.trim());

        System.out.println(trim_text.intern());




    }
}
