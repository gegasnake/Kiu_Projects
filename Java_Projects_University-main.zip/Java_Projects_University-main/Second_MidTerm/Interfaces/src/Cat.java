public class Cat {
}
