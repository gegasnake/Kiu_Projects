public interface Runner {
    void run();

}
