public interface Swimmer {
    void swim();
}
