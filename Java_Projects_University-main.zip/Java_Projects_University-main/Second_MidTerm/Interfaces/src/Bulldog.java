public class Bulldog extends Dog implements Runner, Swimmer{

    @Override
    public void run() {
        System.out.println("Bulldog is Running");
    }

    @Override
    public void swim() {
        System.out.println("Bulldog is swimming in the pool");
    }
}
