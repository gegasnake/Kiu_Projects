public interface Animal {
    void eat();

    default void breath(){
        System.out.println("Breathing in and breathing out");
    }
}