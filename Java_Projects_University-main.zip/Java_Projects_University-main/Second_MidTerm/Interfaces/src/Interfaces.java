public class Interfaces {
    public static void main(String[] args){
        Dog mydog = new Dog();

        mydog.eat();
        mydog.breath();
    }
}
