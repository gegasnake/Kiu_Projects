public class Annonymous_Classes {
    public static void main(String[] args){
        Animal myAnimal = new Animal() {
            @Override
            public void makeNoise() {
                System.out.println("Meow");
            }
        };
        myAnimal.makeNoise();

    }
}
