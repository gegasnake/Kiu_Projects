interface Animal {
    void makeNoise();
}