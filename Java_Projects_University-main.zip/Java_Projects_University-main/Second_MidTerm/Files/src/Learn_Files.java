import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class Learn_Files {

    public static void main(String[] args) throws IOException {
        // BufferedWriter
        // BufferedReader
        try {
            BufferedWriter file = new BufferedWriter(new FileWriter("output.txt"));
            file.write("Hello ");
            file.write("World");
            file.write("!");
            file.close();
        }catch (IOException exception){
            System.out.println("Error");
        }

        File file = new File("output.txt");
        System.out.println(file.getAbsoluteFile());
        System.out.println(file.canRead());
        System.out.println(file.canWrite());
        System.out.println(file.isHidden());
        System.out.println(file.setReadOnly());
        System.out.println(file.canWrite());
        System.out.println(Files.readString(Path.of(file.toURI())));

    }
}
