public class Dog extends Animal{
    @Override
    public void breath() {
        System.out.println("* bark *");
    }
}

