class Animal {
    public void breath(){
        System.out.println("* Breathe noises *");
    }

}



public class Main {
    public static void main(String[] args){
        Animal x = new Animal();
        x.breath();
        Dog jeka = new Dog();
        jeka.breath();
    }

}

