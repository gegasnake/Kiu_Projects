public class Main {
    public static void main(String[] args) throws InterruptedException {
        // System.out.println(Thread.activeCount());
        // Thread.currentThread().setName("Gega");
        // System.out.println(Thread.currentThread().getName());
        //Thread.currentThread().setPriority(10);
        //System.out.println(Thread.currentThread().getPriority());
        //System.out.println(Thread.currentThread().isAlive());

//        for(int i = 3; i > 0; i--){
//            System.out.println(i);
//            Thread.sleep(1000);
//        }
//        System.out.println("You are done!");

//        MyThread thread2 = new MyThread();
//        thread2.start();
//        thread2.join();
//        System.out.println("Hello");

        //System.out.println(thread2.isAlive());
        //System.out.println(thread2.getName());
        //System.out.println(thread2.getPriority());
        //System.out.println(Thread.activeCount());


        MyThread thread1 = new MyThread();
        myRunnable runnable1 = new myRunnable();
        Thread thread2 = new Thread(runnable1);
//        thread1.setPriority(10);
//        thread2.setPriority(1);
        thread1.start();
        thread1.join(3000);
        thread2.start();

        // System.out.println(1 / 0);
    }
}