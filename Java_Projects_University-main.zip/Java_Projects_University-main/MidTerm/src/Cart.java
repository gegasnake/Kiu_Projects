//package mid2.template.mechanic;
import java.util.HashMap;
import java.util.Map;


public class Cart<T extends CarPart>{

    private Map<T, Integer> cart = new HashMap<T, Integer>();

    public Map<T, Integer> getCart() {
        return cart;
    }

    public void addItem(T item, int n){
        if (item == null || n < 0) {
            throw new IllegalArgumentException("Item cannot be null and n must be greater than 0");
        }

        if (cart.get(item) != null){
            cart.replace(item, cart.get(item), cart.get(item) + n);
        }else{
            cart.put(item, n);
        }

    }

    public boolean removeItem(T item, int n){
        if (item == null || n < 0) {
            throw new IllegalArgumentException("Item cannot be null and n must be greater than 0");
        }

        if (cart.get(item) != null){
            if (n > cart.get(item)){
                throw new IllegalArgumentException("n can't be more than the current stock, current stock: " + cart.get(item));
            }else if(n == cart.get(item)) {
                cart.remove(item);
                return true;
            }else{
                cart.replace(item, cart.get(item), cart.get(item) - n);
                return true;
            }
        }
        return false;
    }

    public int calculatePrice(){
        int count = 0;
        for (T object : cart.keySet()){
            count += cart.get(object) * object.getPrice();
        }
        return count;
    }

    public int checkout(int money){
        if (calculatePrice() > money){
            throw new IllegalArgumentException("The money isn't enough to buy everything");
        }else{
            cart.clear();
            return money - calculatePrice();
        }
    }


    public int getPrice() {
        return calculatePrice();
    }
}
