public class Main {
    public static void main(String[] args){
        CarPart part = new CarPart("zrava", 10);
        CarPart part2 = new CarPart("zrava", 10);
        Cart cart1 = new Cart();
        Mechanic gega = new Mechanic("Gega Tvaradze", 120, 50, cart1);
        cart1.addItem(part, 7);
        cart1.removeItem(part, 4);
        System.out.println(cart1.getPrice());
        gega.addItemToCart(part, 10);
        System.out.println(cart1.getPrice());
        System.out.println(cart1);
        gega.buyItemsFromCart();
    }
}
