//package mid2.template.mechanic;
public class Mechanic extends Customer{
    private int reduction;

    protected Cart<CarPart> cart;

    public Mechanic(String name, int money, int reduction, Cart<CarPart> cart) {
        super(name, money, cart);
        this.cart = cart;
        if (reduction < 0){
            throw new IllegalArgumentException("The percent must be more than 0");
        }else{
            this.reduction = reduction;
        }

    }

    public int getReduction() {
        return reduction;

    }


    @Override
    public boolean buyItemsFromCart() throws IllegalArgumentException{
        int mechanic_bill = (cart.checkout(getMoney()) + cart.getPrice()) * reduction / 100;
        return getMoney() - mechanic_bill >= 0;

    }
}
