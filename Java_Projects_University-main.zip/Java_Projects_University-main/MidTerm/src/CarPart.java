//package mid2.template.mechanic;
import java.util.Objects;

interface MarketItem {
    int getPrice();
}


public class CarPart implements MarketItem{
    private final String name;
    private final int price;

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public CarPart(String name, int price) {
        if (name == null || price < 0){
            throw new IllegalArgumentException();
        }else{
            this.name = name;
            this.price = price;
        }

    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        CarPart carPart = (CarPart) object;
        return Objects.equals(name, carPart.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }


}