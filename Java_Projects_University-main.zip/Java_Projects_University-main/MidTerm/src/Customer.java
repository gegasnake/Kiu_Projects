//package mid2.template.mechanic;
public class Customer {
    private String name;
    private int money;
    protected Cart<CarPart> cart;

    public Customer(String name, int money, Cart<CarPart> cart) {
        if (name == null || money < 0){
            throw new IllegalArgumentException("The name must be provided and money must be a positive number");
        }else{
            this.name = name;
            this.money = money;
        }
        this.cart = cart;

    }

    public String getName() {
        return name;
    }

    public int getMoney() {
        return money;
    }
    public void addItemToCart(MarketItem item, int n) throws IllegalArgumentException{
        cart.addItem((CarPart) item, n);

    }

    public boolean removeItemFromCart(MarketItem item, int n) throws IllegalArgumentException{
        return cart.removeItem((CarPart) item, n);
    }

    public boolean buyItemsFromCart() throws IllegalArgumentException{
        if (cart.checkout(getMoney()) >= 0){
            return true;
        }else{
            return false;
        }
    }
}
