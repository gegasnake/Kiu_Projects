public class Queue2 {
    // Define private variables for the first and last elements of the queue
    private List first, last;

    // Constructor: Initialize the first and last to null when the queue is created
    public Queue2() {
        first = last = null;
    }

    // Inner List class with an integer field
    private static class List {
        int info; // Information stored in the list node
        List next; // Reference to the next node in the list

        // Constructor to create a new list node with the given information
        public List(int info) {
            this.info = info;
            this.next = null;
        }

        // Static method to convert the list to a string for easy printing
        public static String toString(List first) {
            StringBuilder result = new StringBuilder("[");
            List current = first;
            while (current != null) {
                result.append(current.info);
                if (current.next != null) {
                    result.append(", ");
                }
                current = current.next;
            }
            result.append("]");
            return result.toString();
        }
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return first == null;
    }

    // Method to remove and return the front element of the queue
    public int dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }

        int result = first.info; // Retrieve the information from the front node
        if (last == first) {
            last = null; // If there's only one element, set last to null
        }
        first = first.next; // Move the front pointer to the next node
        return result;
    }

    // Method to add a new element to the back of the queue
    public void enqueue(int x) {
        if (first == null) {
            // If the queue is empty, create a new list node and set both first and last to it
            first = last = new List(x);
        } else {
            // If the queue is not empty, create a new list node, set last's next to it, and update last
            last = last.next = new List(x);
        }
    }

    // Override the toString method to provide a string representation of the queue
    @Override
    public String toString() {
        return List.toString(first);
    }

    // Main method for testing the Queue2 class
    public static void main(String[] args) {
        Queue2 myQueue = new Queue2(); // Create a new queue

        // Enqueue some elements into the queue
        myQueue.enqueue(1);
        myQueue.enqueue(2);
        myQueue.enqueue(3);
        myQueue.enqueue(80);
        myQueue.enqueue(107);
        myQueue.enqueue(24);

        // Print the elements of the queue
        System.out.println("Queue elements: " + myQueue);

        // Dequeue and print the result
        System.out.println("Dequeue: " + myQueue.dequeue());

        // Print the elements of the queue after dequeue
        System.out.println("Queue elements after dequeue: " + myQueue);

        // Dequeue again and print the result
        System.out.println("Dequeue: " + myQueue.dequeue());

        // Print the elements of the queue after the second dequeue
        System.out.println("Queue elements after dequeue: " + myQueue);

        while (!myQueue.isEmpty()) {
            System.out.println("Dequeue: " + myQueue.dequeue());
            System.out.println("Queue elements: " + myQueue);
        }
    }
}
