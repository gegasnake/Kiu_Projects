public class Queue1 {
    // Variables to represent the front and rear of the queue
    private int first, last;

    // Array to store elements of the queue
    private int[] array;

    // Constructor: Initialize the queue with an initial capacity of 4
    public Queue1() {
        // -1 indicates an empty queue
        first = last = -1;

        // Initial capacity of the array
        array = new int[4];
    }

    // Check if the queue is empty
    public boolean isEmpty() {
        return first == -1;
    }

    // Enqueue: Add an element to the rear of the queue
    public void enqueue(int x) {
        if (first == -1) {
            // If the queue is empty, set both first and last to 0
            first = last = 0;
        } else {
            int n = array.length;

            // Circular increment to the next position
            last = (last + 1) % n;

            // If the queue is full, double the array size
            if (last == first) {
                int[] newArray = new int[2 * n];

                // Copy elements from the old array to the new array
                for (int i = 0; i < n; ++i) {
                    newArray[i] = array[(first + i) % n];
                }

                // Reset first and last pointers and update the array reference
                first = 0;
                last = n;
                array = newArray;
            }
        }

        // Add the element to the rear of the queue
        array[last] = x;
    }

    // Dequeue: Remove and return the element from the front of the queue
    public int dequeue() {
        // Retrieve the element at the front of the queue
        int result = array[first];

        // If there is only one element in the queue, reset first and last
        if (last == first) {
            first = last = -1;
            return result;
        }

        int n = array.length;

        // Circular increment to the next position
        first = (first + 1) % n;

        // Check if the array can be resized to save space
        int diff = (last + n - first) % n;
        if (diff > 0 && diff < n / 4) {
            int[] newArray = new int[n / 2];

            // Copy elements from the old array to the new array
            for (int i = 0; i <= diff; ++i) {
                newArray[i] = array[(first + i) % n];
            }

            // Reset first and last pointers and update the array reference
            first = 0;
            last = diff;
            array = newArray;
        }

        return result;
    }
    @Override
    public String toString() {
        if (isEmpty()) {
            return "[]";
        }

        StringBuilder result = new StringBuilder("[");
        int i = first;

        do {
            result.append(array[i]);
            i = (i + 1) % array.length;

            if (i != (last + 1) % array.length) {
                result.append(", ");
            }
        } while (i != (last + 1) % array.length);

        result.append("]");

        return result.toString();
    }


    public static void main(String[] args) {
        Queue1 myQueue = new Queue1();

        // Enqueue elements
        myQueue.enqueue(1);
        myQueue.enqueue(2);
        myQueue.enqueue(3);

        // Print the initial state of the queue
        System.out.println("Initial Queue elements: " + myQueue);

        // Dequeue an element
        System.out.println("Dequeue: " + myQueue.dequeue());

        // Print the state of the queue after the first dequeue
        System.out.println("Queue elements after first dequeue: " + myQueue);

        // Enqueue more elements to trigger array resizing
        myQueue.enqueue(4);
        myQueue.enqueue(5);
        myQueue.enqueue(6);

        // Print the state of the queue after enqueueing more elements
        System.out.println("Queue elements after enqueueing more elements: " + myQueue);

        // Dequeue elements until the queue is empty
        while (!myQueue.isEmpty()) {
            System.out.println("Dequeue: " + myQueue.dequeue());
            System.out.println("Queue elements: " + myQueue);
        }

        // Try to dequeue from an empty queue (will throw an exception)
        // Uncomment the following lines to test the exception handling
        // try {
        //     System.out.println("Dequeue: " + myQueue.dequeue());
        // } catch (Exception e) {
        //     System.out.println("Exception caught: " + e.getMessage());
        // }
    }

}
