public class Rectangle extends BaseArea{
    private double width;
    private double height;

    public Rectangle(double width, double height){
        this.height = height;
        this.width = width;
    }

    public boolean isSquare(){
        return this.width == this.height;
    }
    public double circumference() {
        return (height + width) * 2;
    }

    public Square toSquare(){
        if (isSquare()){
            return new Square(width);
        }
        return null;
    }

    public double area(){
        return width * height;
    }

    public double getHeight() {
        return height;
    }

    public double getWidth() {
        return width;
    }

    @Override
    public String toString() {
        return "Rectangle Height: " + this.height + "and Width: " + this.width;
    }
}
