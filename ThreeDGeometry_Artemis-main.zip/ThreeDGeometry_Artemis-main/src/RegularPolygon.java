public class RegularPolygon extends BaseArea{
    private int n;
    private double length;

    public RegularPolygon(int n, double length){
        this.n = n;
        this.length = length;
    }

    public boolean isSquare(){
        if (n == 4){
            return true;
        }
        return false;
    }

    public Square toSquare(){
        if (n == 4){
            return new Square(length);
        }
        return null;
    }
    public double circumference() {
        return n * length;
    }

    public int getN() {
        return n;
    }

    public double getLength() {
        return length;
    }

    public double area(){
        return n * length * length / 4 / Math.tan(Math.PI / n);
    }

    @Override
    public String toString() {
        return "Length of RegularPolygon: " + length;
    }
}
