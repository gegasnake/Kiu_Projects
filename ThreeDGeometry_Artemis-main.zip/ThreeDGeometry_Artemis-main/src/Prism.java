public class Prism {
    private double height;
    private BaseArea base;

    public Prism(double height, BaseArea base){
        this.height = height;
        this.base = base;
    }

    public double surface(){
        return base.area();
    }

    public double volume(){
        return base.area() * this.height;
    }

    public boolean isCube(){
        if (base.isSquare() && base.area() == this.height * this.height){
            return true;
        }
        return false;
    }

    public BaseArea getBase() {
        return base;
    }

    public double getHeight() {
        return height;
    }

    @Override
    public String toString() {
        return "This is a Prism with the height: " + this.height;
    }
}
