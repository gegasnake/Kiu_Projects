public class Circle extends BaseArea{
    private double radius;

    public Circle(double radius){
        this.radius = radius;
    }

    public double area(){
        return radius * radius * Math.PI;
    }

    public double circumference() {
        return 2 * Math.PI * radius;
    }

    public double getRadius() {
        return radius;
    }

    @Override
    public String toString() {
        return "Area of the circle: " + this.area();
    }
}
