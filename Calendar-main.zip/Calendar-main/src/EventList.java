public class EventList {
    private Event event;
    private EventList next;

    public EventList(Event event) {
        this.event = event;
    }

    protected EventList(Event event, EventList next) {
        this.event = event;
        this.next = next;
    }

    public Event getEvent() {
        return event;
    }

    public EventList getNext() {
        return next;
    }

    public EventList add(Event event) {
        next = new EventList(event, next);
        return next;
    }

    @Override
    public String toString() {
        String result = "[" + event;
        EventList t = next;
        while(t != null){
            result += ", " + t.event;
            t = t.next;
        }
        result += "]";
        return result;
    }
}
