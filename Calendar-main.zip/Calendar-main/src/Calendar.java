public class Calendar {
    EventList events;

    public Calendar(EventList events){
        this.events = events;
    }

    public void addNewEvent(Event event){
        events.add(event);
    }

    public Event[] eventsAt(int day){
        int element_count = 0;
        for (EventList next = events; next != null; next = next.getNext()){
            element_count++;
        }
        Event[] ev = new Event[element_count];
        int index = 0;
        for (EventList next = events; next != null; next = next.getNext()){
            if (next.getEvent().diff(day) == 0){
                ev[index] = next.getEvent();
                index++;
            }
        }
        return ev;
    }

    public Event nextEvent(int day){
        for (EventList next = events; next != null; next = next.getNext()){
            if (events.getEvent().diff(day) == 0){
                return events.getEvent();
            }
        }
        return null;
    }

}
