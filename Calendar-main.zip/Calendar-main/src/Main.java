public class Main {
    public static void main(String[] args) {
        EventList list_of_events = new EventList(new Event(25, "Sexy day", "China"));
        list_of_events.add(new Event(15, "ksovro day", "Kiu"));
        System.out.println(list_of_events);

        Calendar calendar = new Calendar(list_of_events);

    }
}