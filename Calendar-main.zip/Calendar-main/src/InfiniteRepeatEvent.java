public class InfiniteRepeatEvent extends Event{
    private int period;

    public InfiniteRepeatEvent(int day, String description, String place, int period) {
        super(day, description, place);
        this.period = period;
    }

    public int diff(int day2){
        while(day2 > this.getDay()){
            day2 -= period;
        }

        return day2 - this.getDay();
    }

    public int getPeriod() {
        return period;
    }
}
