public class RepeatEvent extends InfiniteRepeatEvent{
    private int end;

    public RepeatEvent(int day, String description, String place, int period, int end) {
        super(day, description, place, period);
        this.end = end;
    }

    public int diff(int day2){
        int x = this.getDay();
        if (day2 > end){
            while (x < end){
                x += this.getPeriod();
            }

            return day2 - x;
        }else{
            while(day2 > this.getDay()){
                day2 -= this.getPeriod();
            }
            return this.getDay() - day2;
        }

    }

    public int getEnd() {
        return end;
    }
}
