public interface Meaning<T> {
    T meaning();
}
