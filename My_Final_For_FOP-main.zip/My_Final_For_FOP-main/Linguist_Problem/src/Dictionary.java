import java.util.HashMap;
import java.util.Map;

public class Dictionary<T> {
    private Map<Character, Dictionary<T>> h;
    private T value;
    public Dictionary(T value, Map<Character, Dictionary<T>> h) {
        this.value = value;
        this.h = h;
    }

    public void record(String s, T value){
        if (s.length() == 1){
            h.put(s.toCharArray()[0], new Dictionary<>(value, new HashMap<>()));
        }
        this.record(s.substring(1), new Dictionary<>(value, new HashMap<>()).getValue());
    }


    public T lookup(String s){
        if (s.length() == 1 && h.containsKey(s.toCharArray()[0])){
            return h.get(s.toCharArray()[0]).getValue();
        }
        if (h.containsKey(s.charAt(0))){
            return h.get(s.charAt(0)).lookup(s.substring(1));
        }

        return null;

    }


    public T getValue() {
        return value;
    }

    public T remove(String s){
        if (s.length() == 1 && h.containsKey(s.toCharArray()[0])){
            return h.remove(s.toCharArray()[0]).getValue();
        }
        if (h.containsKey(s.charAt(0))){
            return h.get(s.charAt(0)).remove(s.substring(1));
        }

        return null;
    }
    public boolean isEmpty(){
        return h.isEmpty();
    }



    public static void main(String[] args) {
        Dictionary<Meaning<Integer>> dictionary = new Dictionary<>(null, null);
        for (int i = 0; i < args.length; i++){
            int x = i;
            dictionary.record(args[i], () -> x);
        }

        for (String s: args){
            System.out.println("foo " + dictionary.getValue());
            dictionary.remove(s);
        }

    }


}
