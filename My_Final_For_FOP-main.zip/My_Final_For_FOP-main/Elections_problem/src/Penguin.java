public interface Penguin {
    void vote() throws InterruptedException;
}
