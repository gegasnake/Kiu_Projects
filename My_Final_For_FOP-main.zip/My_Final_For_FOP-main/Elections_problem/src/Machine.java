public class Machine extends Thread{
    private PenguinVoters object;
    boolean interrupted = false;
    public Machine(PenguinVoters object) {
        this.object = object;
    }

    @Override
    public void run() {
        try {
            while(!interrupted){
                object.vote();
            }
        } catch (InterruptedException e) {
            return;
        }


    }
}
