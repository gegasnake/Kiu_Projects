import java.util.ArrayList;
import java.util.List;

public class PenguinVoters implements Penguin{
    List<Penguin> list = new ArrayList<>();

    synchronized void register(Penguin p) throws InterruptedException {
        if (p == null){
            wait();
        }
        list.add(p);
        notify();
    }

   synchronized Penguin admit() throws InterruptedException {
        while (list.isEmpty()){
            wait();
        }

        return list.removeFirst();
    }

    @Override
    public void vote() throws InterruptedException {
        System.out.println("Voting");
    }
}
