public class Election {
    private PenguinVoters pv;
    private Machine[] machines;

    public Election(int n) throws InterruptedException {
        machines = new Machine[n];
        if (machines.length == 0){
            wait();
        }
        for (int i = 0; i < n; i++){
            machines[i] = new Machine(pv);
        }
        for (Machine i: machines){
            i.start();
        }

    }

    public synchronized void arrive (Penguin p) throws InterruptedException {
        pv = (PenguinVoters) p;
        pv.register(p);
        notifyAll();
    }

    public void shutdown() throws InterruptedException{
        for (Machine machine : machines) {
            machine.interrupt();
            machine.interrupted = true;
        }
        System.out.println("Shutting down!");
    }

    public static void main(String[] args) throws InterruptedException {
        Election e = new Election(4);
        Penguin first = new Penguin() {
            @Override
            public void vote() throws InterruptedException {
                System.out.println("peng");
                System.out.println("guin");
            }
        };
        Penguin second = new Penguin() {
            @Override
            public void vote() throws InterruptedException {
                System.out.println("peng");
                System.out.println("guin");
            }
        };
        Penguin third = new Penguin() {
            @Override
            public void vote() throws InterruptedException {
                System.out.println("peng");
                System.out.println("guin");
            }
        };
        Penguin fourth = new Penguin() {
            @Override
            public void vote() throws InterruptedException {
                System.out.println("peng");
                System.out.println("guin");
            }
        };
        e.arrive(first);
        e.arrive(second);
        e.arrive(third);
        e.arrive(fourth);

        Thread.sleep(1000);

        e.shutdown();




    }
}
