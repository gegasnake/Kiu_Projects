package fop.w9colony;

public enum Gender {
    FEMALE, MALE
}
