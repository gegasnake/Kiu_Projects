package fop.w9colony;

import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PenguinColony {

    private HashSet<Penguin> penguins;

    public PenguinColony(HashSet<Penguin> penguins) {
        this.penguins = penguins;
    }

    public HashSet<Penguin> getPenguins() {
        return penguins;
    }

    public void setPenguins(HashSet<Penguin> penguins) {
        this.penguins = penguins;
    }

    public void uniteColonies(PenguinColony otherColony) {
        this.penguins.addAll(otherColony.getPenguins());
        otherColony.getPenguins().clear();
    }

    public PenguinColony splitColony(Predicate<? super Penguin> pred) {
        HashSet<Penguin> newColonyPenguins = new HashSet<>();

        Iterator<Penguin> iterator = this.penguins.iterator();
        while (iterator.hasNext()) {
            Penguin currentPenguin = iterator.next();

            if (pred.test(currentPenguin)) {
                newColonyPenguins.add(currentPenguin);
                iterator.remove();
            }
        }

        // Create a new colony with the collected penguins
        PenguinColony newColony = new PenguinColony(newColonyPenguins);
        return newColony;
    }

    public Penguin findFirstFriend(LinkedList<Penguin> penguinFriends) {
        Optional<Penguin> firstFriend = penguinFriends.stream()
                .filter(this.penguins::contains)
                .findFirst();

        return firstFriend.orElse(null);
    }

    public boolean canFeedPenguinsWithProperty(Predicate<? super Penguin> pred, Set<Fish> fishes) {
        return this.penguins.stream()
                .filter(pred) // Filter penguins based on the predicate
                .allMatch(penguin -> fishes.contains(penguin.getFavoriteFish()));
    }

    public int computeSum(Function<? super Penguin, Integer> fun) {
        return this.penguins.stream().map(fun).reduce(0, Integer::sum);
    }

}
