package fop.w9colony;

public enum Fish {
    SILVERFISH, SARDELLE, SARDINE
}
