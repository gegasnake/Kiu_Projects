package fop.w11shop;

public class Main {
    public static void main(String[] args) throws InterruptedException {

        BookShop shop = new BookShop();
        shop.addBooksInStore(7500);

        Customer peter = new Customer("Peter", shop);
        Customer paul = new Customer("Pauls", shop);

        Thread peter_thread = new Thread(peter::buy5000Books);
        peter_thread.setPriority(5);
        Thread paul_thread = new Thread(paul::buy5000Books);
        paul_thread.setPriority(3);

        paul_thread.start();
        peter_thread.start();

        // Wait for both threads to finish
        paul_thread.join();
        peter_thread.join();

        shop.printSummary();
        peter.printSummary();
        paul.printSummary();
    }
}
