package pgdp.collections;

public class List<E> {
    private final E info;
    private List<E> next;

    public List(E x) {
        info = x;
        next = null;
    }

    public List(E x, List<E> l) {
        info = x;
        next = l;
    }

    public void insert(E x) {
        next = new List<>(x, next);
    }

    public void delete() {
        if (next != null)
            next = next.next;
    }

    public int length() {
        int result = 1;
        for (List<E> t = next; t != null; t = t.next)
            result++;
        return result;
    }

    @Override
    public String toString() {
        String result = "[" + info;
        for (List t = next; t != null; t = t.next)
            result = result + ", " + t.info;
        return result + "]";
    }

    public E getInfo() {
        return info;
    }

    public List<E> getNext() {
        return next;
    }
}
