package pgdp.collections;

public class PenguinSupermarket extends ExceptionUtil{
    private CheckOut[] checkOuts;
    private int registers;

    public PenguinSupermarket(int registers) {
        if (registers < 0){
            illegalArgument("Illegal register number was provided");
        }

        this.registers = registers;
    }

    public CheckOut[] getCheckOuts() {
        return checkOuts;
    }

    public CheckOut getCheckoutWithSmallestQueue(){
        int min = checkOuts[0].queueLength();
        int index = 0;
        for (int i = 1; i < registers; i++){
            if (checkOuts[i].queueLength() < min){
                index = i;
            }
        }
        return checkOuts[index];
    }

    public CheckOut[] closeCheckout(int index){
        if (index >= registers || index < 0){
            illegalArgument("The index is out of range");
        }
        CheckOut[] new_checkOuts = new CheckOut[registers - 1];
        LinkedQueue<PenguinCustomer> queue = (LinkedQueue<PenguinCustomer>) checkOuts[index].getQueue();
        LinkedQueue<PenguinCustomer> min_queue = (LinkedQueue<PenguinCustomer>) getCheckoutWithSmallestQueue().getQueue();
        QueueConnector<PenguinCustomer> old_queue = new QueueConnector<>(queue);
        QueueConnector<PenguinCustomer> new_queue = new QueueConnector<>(min_queue);
        DataStructureLink<PenguinCustomer> reversed_queue = new DataStructureLink<>(old_queue, new_queue);
        reversed_queue.moveAllFromAToB();
        System.arraycopy(checkOuts, 0, new_checkOuts, 0, index);

        System.arraycopy(checkOuts, index + 1, new_checkOuts, index, registers - index - 1);
        registers--;
        return new_checkOuts;


    }

    public void serveCustomers(){
        for (int i = 0; i < registers; i++){
            while (!checkOuts[i].getQueue().isEmpty()){
                checkOuts[i].serveNextCustomer();
            }
        }
    }


}
