package pgdp.collections;

public class LinkedStack<T> extends ExceptionUtil implements Stack<T> {
    private List<T> list;

    LinkedStack(){
        this.list = null;
    }
    @Override
    public int size() {
        return list.length();
    }

    @Override
    public boolean isEmpty() {
        return list == null;
    }

    @Override
    public void push(T T) {
        if (!isEmpty()){
            this.list = new List<>(T, this.list);
        }else{
            this.list = new List<>(T);
        }

    }

    public List<T> getList() {
        return list;
    }

    @Override
    public T pop() throws UnsupportedOperationException {
        if (isEmpty()){
            unsupportedOperation("can't pop when the list is empty");
        }else{
            T popped_value = this.list.getInfo();
            this.list = this.list.getNext();
            return popped_value;
        }
        return null;
    }
}
