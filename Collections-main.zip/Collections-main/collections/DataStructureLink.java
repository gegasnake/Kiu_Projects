package pgdp.collections;

public class DataStructureLink<T>{
    private DataStructureConnector<T> firstConnector;
    private DataStructureConnector<T> secondConnector;

    public DataStructureLink(DataStructureConnector<T> firstConnector, DataStructureConnector<T> secondConnector){
        this.firstConnector = firstConnector;
        this.secondConnector = secondConnector;
    }

    public boolean moveNextFromAToB(){
        if (firstConnector.hasNextElement()){
            secondConnector.addElement(firstConnector.removeNextElement());
            return true;
        }else{
            return false;
        }
    }

    public void moveAllFromAToB(){
        if (!firstConnector.hasNextElement()){
            return;
        }else{
            while(firstConnector.hasNextElement()){
                secondConnector.addElement(firstConnector.removeNextElement());
            }
        }
    }

    public DataStructureConnector<T> getQueueConnector() {
        return firstConnector;
    }

    public DataStructureConnector<T> getStackConnector() {
        return secondConnector;
    }
}
