package pgdp.collections;

public class LinkedQueue<T> extends ExceptionUtil implements Queue<T>{
    private List<T> list;

    LinkedQueue(){
        this.list = null;
    }

    public List<T> getList() {
        return list;
    }

    @Override
    public int size() {
        return list.length();
    }

    @Override
    public boolean isEmpty() {
        return list == null;
    }

    @Override
    public void enqueue(T T) {
        if (isEmpty()){
            this.list = new List<>(T);
        }else{
            this.list = new List<>(T, this.list);
        }
    }

    @Override
    public T dequeue() throws UnsupportedOperationException{
        if (isEmpty()) {
            unsupportedOperation("Queue is empty");
        }

        T frontElement = list.getInfo();
        list = list.getNext();
        return frontElement;
    }
}
