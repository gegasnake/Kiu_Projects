package pgdp.collections;

public interface DataStructure {
    int size();
    boolean isEmpty();
}
