package pgdp.collections;

public class FishyProduct extends ExceptionUtil{
    private final String name;
    private final int price;

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public FishyProduct(String name, int price) {
        if (name == null){
            illegalArgument("The name is not valid");
        }else if (price <= 0){
            illegalArgument("The price is not valid");
        }
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return "FishyProduct{" +
                "name='" + name + '\'' +
                ", price=" + price +
                '}';
    }
}
