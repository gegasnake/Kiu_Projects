package pgdp.collections;

public class StackConnector<T> implements DataStructureConnector<T>{
    private LinkedStack<T> stack;

    public StackConnector(LinkedStack<T> stack){
        this.stack = stack;
    }

    @Override
    public boolean hasNextElement() {
        return stack.getList().getNext() != null;
    }

    @Override
    public void addElement(T T) {
        stack.push(T);
    }

    @Override
    public T removeNextElement() {
        return stack.pop();
    }
}
