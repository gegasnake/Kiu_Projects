package pgdp.collections;

public class PenguinCustomer extends ExceptionUtil{
    private final String name;
    private int money;

    private Stack<FishyProduct> products;

    public PenguinCustomer(String name, int initialMoney) {
        if (name == null){
            illegalArgument("Illegal name was provided");
        }else if(initialMoney < 0){
            illegalArgument("Penguins don't have debts");
        }
        this.name = name;
        this.money = initialMoney;
    }

    public String getName() {
        return name;
    }

    public int getMoney() {
        return money;
    }

    public Stack<FishyProduct> getProducts() {
        return products;
    }

    public void addProductToBasket(FishyProduct fishyProduct) {
        products.push(fishyProduct);
    }

    public QueueConnector<FishyProduct> placeAllProductsOnBand(Queue<FishyProduct> queue) {
        QueueConnector<FishyProduct> new_queue = new QueueConnector<>((LinkedQueue<FishyProduct>) queue);
        StackConnector<FishyProduct> new_stack = new StackConnector<>((LinkedStack<FishyProduct>) products);
        DataStructureLink<FishyProduct> dataStructureLink = new DataStructureLink<>(new_stack, new_queue);
        dataStructureLink.moveAllFromAToB();
        return (QueueConnector<FishyProduct>) dataStructureLink.getQueueConnector();
    }

    public StackConnector<FishyProduct> takeAllProductsFromBand(Queue<FishyProduct> queue){
        QueueConnector<FishyProduct> new_queue = new QueueConnector<>((LinkedQueue<FishyProduct>) queue);
        StackConnector<FishyProduct> new_stack = new StackConnector<>((LinkedStack<FishyProduct>) products);
        DataStructureLink<FishyProduct> dataStructureLink = new DataStructureLink<>(new_queue, new_stack);
        dataStructureLink.moveAllFromAToB();
        return (StackConnector<FishyProduct>) dataStructureLink.getStackConnector();
    }

    public void pay(int amount){
        if (amount < 0){
            illegalArgument("The amount can't be negative");
        }else{
            if (money - amount < 0){
                System.out.println("penguins can't be in debt");
            }else{
                money -= amount;
                System.out.println("paid successfully");
            }
        }
    }

    public CheckOut goToCheckout(PenguinSupermarket supermarket){
        return supermarket.getCheckoutWithSmallestQueue();
    }

    @Override
    public String toString() {
        return "PenguinCustomer{" +
                "name='" + name + '\'' +
                ", money=" + money +
                ", products=" + products +
                '}';
    }
}
