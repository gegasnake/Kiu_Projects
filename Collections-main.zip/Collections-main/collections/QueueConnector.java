package pgdp.collections;

public class QueueConnector<T> implements DataStructureConnector<T>{
    private LinkedQueue<T> queue;

    public LinkedQueue<T> getQueue() {
        return queue;
    }

    public QueueConnector(LinkedQueue<T> queue){
        this.queue = queue;
    }
    @Override
    public boolean hasNextElement() {
        return queue.getList().getNext() != null;
    }

    @Override
    public void addElement(T T) {
        queue.enqueue(T);
    }

    @Override
    public T removeNextElement() {
        return queue.dequeue();
    }
}
