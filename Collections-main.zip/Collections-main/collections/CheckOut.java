package pgdp.collections;

public class CheckOut {
    private Queue<PenguinCustomer> queue;
    private Queue<FishyProduct> bandBeforeCashier;
    private Queue<FishyProduct> bandAfterCashier;

    CheckOut(){}

    public Queue<PenguinCustomer> getQueue() {
        return queue;
    }

    public Queue<FishyProduct> getBandBeforeCashier() {
        return bandBeforeCashier;
    }

    public Queue<FishyProduct> getBandAfterCashier() {
        return bandAfterCashier;
    }

    public int queueLength(){
        return queue.size();
    }

    public void serveNextCustomer(){
        PenguinCustomer first_penguin = queue.dequeue();
        if (first_penguin == null){
            return;
        }
        QueueConnector<FishyProduct> before = first_penguin.placeAllProductsOnBand(bandBeforeCashier);
        StackConnector<FishyProduct> after = first_penguin.takeAllProductsFromBand(bandAfterCashier);
        int price = 0;
        while (after.hasNextElement()){
            FishyProduct product = after.removeNextElement();
            price += product.getPrice();
            first_penguin.addProductToBasket(product);
        }

        first_penguin.pay(price);
    }

    @Override
    public String toString() {
        return "CheckOut{" +
                "queue=" + queue +
                ", bandBeforeCashier=" + bandBeforeCashier +
                ", bandAfterCashier=" + bandAfterCashier +
                '}';
    }
}
