import java.util.Arrays;
import java.util.Scanner;

public class PickSix extends MiniJava{
    // sorting method from the lecture
    public static int[] sort(int[] a) {
        int[] b = new int[a.length];
        for (int i = 0; i < a.length; ++i) {
            // begin of insert
            int j = 0;
            while (j < i && a[i] > b[j]) ++j;
            // end of locate
            for (int k = i - 1; k >= j; --k) b[k + 1] = b[k];
            // end of shift
            b[j] = a[i];
            // end of insert
        }
        return b;
    } // end of sort

    public static void main(String[] args) throws IllegalAccessException {
        int [][] players = new int[2][5];
        int [][] batch = new int[4][5];
        givePlayerCards(players);
        batch[0][0] = drawCard();
        batch[1][0] = drawCard();
        batch[2][0] = drawCard();
        batch[3][0] = drawCard();
        for (byte i = 0; i < 10; i++){
            outputBatch(batch);

        }

    }

    public static void outputBatch(int[][] batch) {
        for (byte i = 1; i <= batch.length; i++){
            System.out.print("Batch " + i + ":");
            for (byte x = 0; x < batch[0].length; x++){
                if (batch[i][x] != 0){
                    System.out.print(' ');
                    System.out.print(batch[i][x]);
                }
            }
            System.out.println();
        }

    }

    public static int playerSelectCard(int player, int[][] playerCards) {
        Scanner scanner = new Scanner(System.in);
        while(true){
            System.out.print("Player " + (player + 1) + ", you have the following cards: ");
            for (byte i = 0; i < playerCards[player].length; i++){
                System.out.print(playerCards[player][i]);
                System.out.print(" ");
            }

            System.out.println("\nWhich card do you want to play?");
            byte card = scanner.nextByte();
            for (int i : playerCards[player]){
                if (i == card){
                    return card;
                }
            }
        }

    }

    public static int calculatePoints(int[] lostCards) {
        int value = 0;
        for (int lostCard : lostCards) {
            value += getValueOfCard(lostCard);
        }
        return value;
    }

    public static void outputResult(int[][] playerPoints) {
        int player1 = calculatePoints(playerPoints[0]);
        int player2 = calculatePoints(playerPoints[1]);
        if ( player1 == player2){
            System.out.println("Draw! Both players have " + player1 + " points.");
        }else if(player1 < player2){
            System.out.println("Player 1 wins with " + player1 + " points against player 2 with " + player2 + " points.");
        }else{
            System.out.println("Player 2 wins with " + player2 + " points against player 1 with " + player1 + " points.");
        }
    }

    public static int getValueOfCard(int card) {
        if (card != 0){
            byte value = 1;
            if (card % 10 == 5){
                value++;
            }
            if (card % 10 == card / 10 && card != 100){
                value += 5;
            }
            return value;
        }
        return 0;
    }

    public static void givePlayerCards(int[][] playerCards) throws IllegalAccessException {
        for (byte i = 0; i < playerCards.length; i++){
            for (byte x = 0; x < playerCards[0].length; x++){
                playerCards[i][x] = drawCard();
            }
            playerCards[i] = sort(playerCards[i]);
        }
        System.out.println(Arrays.deepToString(playerCards));

    }
}
