package fop.w8trees;
import java.util.Arrays;
import java.util.Comparator;
import java.util.function.Predicate;

public class Tree<T> {

    private Comparator<T> comp;
    private TreeElement<T> root;

    public Tree(Comparator<T> comp) {
        root = new Leaf<>();
        this.comp = comp;
    }

    public void insert(T value) {
        if (value == null){
            return;
        }else if(root instanceof Leaf){
            root = new InnerNode<>(value);
        } else{
            root.insert(value, comp);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        root.toString(sb);
        return sb.toString();
    }

    public int size() {
        return root.toString().length() / 2 + 1;
    }

    public void remove(T value) {
        if (contains(value)){
            root.remove(value, comp);
        }
    }
    
    public boolean contains(T value) {
        return root.contains(value, comp);
    }

    public int countMatches(Predicate<T> filter) {
        return root.countMatches(filter);
    }

    public T[] getAll(Predicate<T> filter) {
        // Generics and Arrays do not go together nicely
        @SuppressWarnings("unchecked")
        T[] array = (T[]) new Object[countMatches(filter)];
        root.getAll(filter, array, 0);
        return array;
    }


}
