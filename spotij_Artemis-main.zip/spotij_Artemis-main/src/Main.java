import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Song rattlestarSong = new Song("Snake Jazz", 1989);
        Song majorSong = new Song("Space Oddity", 1969, 315);
        Song queenSong = new Song("Teo Torriatte", 1977, 355, 132178);


        Song snakeJazz = new Song("Snake Jazz", 1989, 30);
        System.out.println(snakeJazz);

        Album greenSide = new Album("Green side",1976, new Song[10]);
        System.out.println(greenSide.getTitle());
        System.out.println(greenSide.addSongs(new Song[]{snakeJazz}));
        System.out.println(greenSide.addSongs(new Song[]{snakeJazz, majorSong}));
        System.out.println(greenSide.addSongs(new Song[]{queenSong, rattlestarSong, queenSong}));
        System.out.println(Arrays.toString(greenSide.shuffle()));
    }
}