import java.util.Arrays;
import java.util.Random;

public class Album {
    private String title;
    private int releaseYear;
    private Song[] songs;

    public Album(String title, int releaseYear, Song[] songs) {
        this.title = title;
        this.releaseYear = releaseYear;
        this.songs = songs;
    }

    public String getTitle() {
        return this.title;
    }

    public int getReleaseYear() {
        return this.releaseYear;
    }

    public Song[] getSongs() {
        return this.songs;
    }

    public int addSongs(Song[] newSongs) {
        int songsAppended = 0;

        for (Song newSong : newSongs) {
            if (newSong != null && !containsSong(newSong)) {
                // If the new song is not null and not already on the album
                for (int i = 0; i < this.songs.length; i++) {
                    if (this.songs[i] == null) {
                        // If an empty slot is found, add the new song
                        this.songs[i] = newSong;
                        songsAppended++;
                        break;
                    }
                }
            }
        }

        return songsAppended;
    }

    private boolean containsSong(Song target) {
        for (Song song : this.songs) {
            if (song != null && song.equals(target)) {
                return true;
            }
        }
        return false;
    }

    private void shuffleSongs(Song[] array) {
        Random random = new Random();
        int n = array.length;

        for (int i = n - 1; i > 0; i--) {
            // Generate a random index between 0 and i (inclusive)
            int randomIndex = random.nextInt(i + 1);

            // Swap elements at i and randomIndex
            Song temp = array[i];
            array[i] = array[randomIndex];
            array[randomIndex] = temp;
        }
    }

    public Song[] shuffle(){
        shuffleSongs(this.songs);
        return this.songs;
    }
}
