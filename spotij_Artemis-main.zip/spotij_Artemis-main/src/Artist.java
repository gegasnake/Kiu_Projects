public class Artist {
}
